// DCMS v1 — full-text search via Elasticsearch
// Postgres remains the source of truth; ES holds a synchronized denormalized index.
// Sync is write-through and best-effort: failures are logged, periodic reindex catches up.

const { Client } = require('@elastic/elasticsearch');

const NODE     = process.env.ES_NODE || 'http://localhost:9200';
const INDEX    = process.env.ES_INDEX || 'dcms_documents';
const USERNAME = process.env.ES_USERNAME || undefined;
const PASSWORD = process.env.ES_PASSWORD || undefined;

const es = new Client({
  node: NODE,
  auth: USERNAME ? { username: USERNAME, password: PASSWORD } : undefined,
});

const MAPPING = {
  settings: {
    analysis: {
      analyzer: {
        // ICU for multilingual content (English / Chinese / Arabic)
        multilingual: {
          tokenizer: 'icu_tokenizer',
          filter: ['icu_folding', 'lowercase'],
        },
        // Edge-ngram for prefix matching on doc_code (e.g. "BR26-ARC")
        code_prefix: {
          tokenizer: 'keyword',
          filter: ['lowercase', 'edge_ngram_filter'],
        },
      },
      filter: {
        edge_ngram_filter: { type: 'edge_ngram', min_gram: 2, max_gram: 20 },
      },
    },
  },
  mappings: {
    properties: {
      project_id:       { type: 'keyword' },
      doc_code: {
        type: 'keyword',
        fields: {
          prefix: { type: 'text', analyzer: 'code_prefix', search_analyzer: 'keyword' },
        },
      },
      title:            { type: 'text', analyzer: 'multilingual' },
      discipline:       { type: 'keyword' },
      doc_type:         { type: 'keyword' },
      source:           { type: 'keyword' },
      current_status:   { type: 'keyword' },
      current_revision: { type: 'keyword' },
      created_at:       { type: 'date' },
      updated_at:       { type: 'date' },
    },
  },
};

async function ensureIndex() {
  try {
    const exists = await es.indices.exists({ index: INDEX });
    if (!exists) {
      await es.indices.create({ index: INDEX, body: MAPPING });
      console.log(`Created ES index "${INDEX}"`);
    } else {
      console.log(`ES index "${INDEX}" already exists`);
    }
  } catch (e) {
    console.error('ES init failed:', e.message);
  }
}

async function upsert(doc) {
  try {
    await es.index({
      index: INDEX,
      id: doc.id,
      document: doc,
      refresh: false,
    });
  } catch (e) {
    console.error(`ES upsert failed for ${doc.id}:`, e.message);
    // Swallow — periodic reindex will catch up
  }
}

async function remove(id) {
  try {
    await es.delete({ index: INDEX, id, refresh: false });
  } catch (e) {
    if (e.meta?.statusCode !== 404) {
      console.error(`ES delete failed for ${id}:`, e.message);
    }
  }
}

async function search({ projectId, q, filters = {}, page = 1, pageSize = 20 }) {
  const from = (page - 1) * pageSize;

  const must = [{ term: { project_id: projectId } }];
  const should = [];
  if (q) {
    should.push(
      { match: { 'doc_code.prefix': { query: q, boost: 3 } } },
      { term:  { doc_code:           { value: q, boost: 5, case_insensitive: true } } },
      { match: { title: { query: q, fuzziness: 'AUTO', boost: 1 } } },
    );
  }
  const filter = [];
  for (const f of ['discipline', 'doc_type', 'source', 'current_status']) {
    if (filters[f]) filter.push({ term: { [f]: filters[f] } });
  }

  const body = {
    from,
    size: pageSize,
    query: {
      bool: {
        must,
        filter,
        should,
        minimum_should_match: q ? 1 : 0,
      },
    },
    sort: q ? ['_score', { updated_at: 'desc' }] : [{ updated_at: 'desc' }],
    highlight: q ? { fields: { title: {}, 'doc_code.prefix': {} } } : undefined,
  };

  const res = await es.search({ index: INDEX, body });
  return {
    total: res.hits.total.value,
    page,
    page_size: pageSize,
    hits: res.hits.hits.map((h) => ({
      ...h._source,
      id: h._id,
      _score: h._score,
      _highlight: h.highlight,
    })),
  };
}

module.exports = { es, ensureIndex, upsert, remove, search, INDEX };
