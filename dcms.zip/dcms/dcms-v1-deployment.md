# DCMS v1 — Deployment

I'm setting up two deployment shapes for DCMS. The single-server shape covers projects up to about 50 people on a 4-core / 8 GB / 100 GB cloud host. The Kubernetes shape is what I use once I'm running multiple projects in the same cluster, or once I need HA and per-team isolation. Both are documented end-to-end here; they share the same Docker images and the same environment variables.

## 1. Production architecture

```
              ┌──────────────────────┐
              │   Browser / desktop  │
              └────────┬─────────────┘
                       │ HTTPS (443)
                       ▼
              ┌──────────────────────┐
              │       Nginx          │  ← reverse proxy + TLS + static frontend
              │  /        → frontend │
              │  /api/v1  → backend  │
              │  /minio   → minio    │  ← presigned URLs pass through here
              └────┬─────────────┬───┘
                   │             │
                   ▼             ▼
          ┌──────────────┐   ┌──────────────┐
          │  Node API ×N │   │ MinIO / S3   │
          └──────┬───────┘   └──────────────┘
                 │
        ┌────────┼────────┐
        ▼        ▼        ▼
   ┌──────┐ ┌──────┐ ┌─────────┐
   │  PG  │ │Redis │ │  Email  │
   └──────┘ └──────┘ └─────────┘
```

The key choices behind this layout:

- **Nginx is the only thing exposed.** It terminates TLS, serves the static frontend bundle, rate-limits, and reverse-proxies everything else.
- **MinIO traffic goes through a subpath (`/minio/`) or a dedicated subdomain (`files.example.com`).** If I'm running on AWS S3 / Alibaba OSS / R2 instead, that entire box disappears and clients talk to the cloud directly.
- **The API is stateless.** Sessions live in JWTs, not server memory, so I can scale it horizontally without sticky sessions.
- **Postgres is stateful.** On a single host I mount a host volume; on Kubernetes I use a StatefulSet with a PVC.
- **Redis is optional for now.** The MVP doesn't use it. I add it when the workflow engine grows SLA reminders that need a queue.

---

## 2. Single-server deployment

### 2.1 Directory layout

```
/opt/dcms/
├── docker-compose.prod.yml
├── .env                    # production secrets
├── nginx/
│   ├── nginx.conf
│   └── conf.d/
│       └── dcms.conf
├── certbot/
│   ├── conf/               # Let's Encrypt certificates
│   └── www/                # ACME challenge directory
└── data/
    ├── postgres/           # PG data (mounted)
    └── minio/              # MinIO data (mounted)
```

### 2.2 .env

```bash
# DOMAIN — required
DOMAIN=dcms.example.com

# DB
DB_HOST=postgres
DB_PORT=5432
DB_USER=dcms
DB_PASSWORD=<32+ character random string, e.g. `openssl rand -base64 32`>
DB_NAME=dcms

# JWT
JWT_SECRET=<32+ character random string>

# S3 / MinIO
S3_ENDPOINT=http://minio:9000
S3_PUBLIC_ENDPOINT=https://dcms.example.com/minio
S3_REGION=us-east-1
S3_BUCKET=dcms-files
S3_ACCESS_KEY=<MinIO root user, rotate before prod>
S3_SECRET_KEY=<MinIO root password, rotate before prod>
S3_FORCE_PATH_STYLE=true

# Email (optional — for workflow reminders)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=dcms@example.com
SMTP_PASSWORD=<...>
SMTP_FROM=dcms@example.com
```

I `chmod 600 .env`.

### 2.3 docker-compose.prod.yml

```yaml
services:
  postgres:
    image: postgres:15-alpine
    restart: always
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME}
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER}"]
      interval: 10s
      timeout: 5s
      retries: 5

  minio:
    image: minio/minio:latest
    restart: always
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: ${S3_ACCESS_KEY}
      MINIO_ROOT_PASSWORD: ${S3_SECRET_KEY}
      MINIO_BROWSER_REDIRECT_URL: https://${DOMAIN}/minio-console
    volumes:
      - ./data/minio:/data
    healthcheck:
      test: ["CMD", "mc", "ready", "local"]
      interval: 30s
      timeout: 20s
      retries: 3

  backend:
    image: dcms-backend:${IMAGE_TAG:-latest}
    restart: always
    env_file: .env
    depends_on:
      postgres:
        condition: service_healthy
      minio:
        condition: service_healthy
    expose:
      - "4000"

  frontend:
    image: dcms-frontend:${IMAGE_TAG:-latest}
    restart: always
    expose:
      - "80"

  nginx:
    image: nginx:1.27-alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./certbot/conf:/etc/letsencrypt:ro
      - ./certbot/www:/var/www/certbot:ro
    depends_on:
      - backend
      - frontend

  certbot:
    image: certbot/certbot:latest
    volumes:
      - ./certbot/conf:/etc/letsencrypt
      - ./certbot/www:/var/www/certbot
    # Renew weekly; certbot decides internally whether to actually renew
    entrypoint: /bin/sh -c 'trap exit TERM; while :; do certbot renew --quiet && nginx -s reload || true; sleep 7d; done'
```

### 2.4 nginx/nginx.conf

```nginx
user nginx;
worker_processes auto;

events { worker_connections 1024; }

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    sendfile on;
    tcp_nopush on;
    keepalive_timeout 65;

    # 200 MB upload limit
    client_max_body_size 200M;
    proxy_request_buffering off;

    gzip on;
    gzip_vary on;
    gzip_types text/plain text/css application/json application/javascript
               application/xml+rss text/javascript;

    # Rate limits: 10 req/sec for API, 5 req/min for login
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;

    include /etc/nginx/conf.d/*.conf;
}
```

### 2.5 nginx/conf.d/dcms.conf

```nginx
# HTTP → HTTPS redirect, keeping the ACME challenge path open
server {
    listen 80;
    server_name dcms.example.com;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name dcms.example.com;

    ssl_certificate     /etc/letsencrypt/live/dcms.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/dcms.example.com/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Login — tighter limit
    location = /api/v1/auth/login {
        limit_req zone=login burst=3 nodelay;
        proxy_pass http://backend:4000;
        include /etc/nginx/conf.d/proxy_common.conf;
    }

    # Other API
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://backend:4000;
        include /etc/nginx/conf.d/proxy_common.conf;
    }

    # MinIO S3 API (presigned upload/download passes through here)
    # In a real prod setup I'd split this onto files.dcms.example.com.
    location /minio/ {
        proxy_pass http://minio:9000/;
        include /etc/nginx/conf.d/proxy_common.conf;
        proxy_set_header Host minio:9000;
        # MinIO can't buffer uploads
        proxy_request_buffering off;
        proxy_buffering off;
        client_max_body_size 200M;
    }

    # MinIO console (internal only)
    location /minio-console/ {
        # IP allowlist for the office VPN, etc.
        # allow 10.0.0.0/8;
        # deny all;
        proxy_pass http://minio:9001/;
        include /etc/nginx/conf.d/proxy_common.conf;
        proxy_set_header Host minio:9001;
    }

    # Frontend SPA
    location / {
        proxy_pass http://frontend:80;
        include /etc/nginx/conf.d/proxy_common.conf;
    }
}
```

### 2.6 nginx/conf.d/proxy_common.conf

```nginx
proxy_http_version 1.1;
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header Upgrade $http_upgrade;
proxy_set_header Connection "upgrade";
proxy_read_timeout 60s;
```

### 2.7 backend/Dockerfile

```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .

FROM node:20-alpine
WORKDIR /app
RUN addgroup -S app && adduser -S app -G app
COPY --from=build --chown=app:app /app /app
USER app
ENV NODE_ENV=production
ENV PORT=4000
EXPOSE 4000
CMD ["node", "server.js"]
```

### 2.8 frontend/Dockerfile

```dockerfile
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:1.27-alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
```

`frontend/nginx.conf` (the SPA fallback):

```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

### 2.9 First certificate

```bash
# 1. DNS: point dcms.example.com → server IP

# 2. Bring up Nginx (HTTP-only first — comment out the 443 server block for the initial pull)
cd /opt/dcms
docker compose -f docker-compose.prod.yml up -d nginx

# 3. Run certbot. I always start with --staging to make sure the flow works,
#    then redo without --staging for the real cert.
docker compose -f docker-compose.prod.yml run --rm certbot certonly \
  --webroot --webroot-path=/var/www/certbot \
  --email admin@example.com --agree-tos --no-eff-email \
  -d dcms.example.com

# 4. Restore the 443 server block, restart nginx
docker compose -f docker-compose.prod.yml restart nginx

# 5. Bring up everything else
docker compose -f docker-compose.prod.yml up -d
```

### 2.10 First-run init

```bash
# Schema
docker compose -f docker-compose.prod.yml exec -T postgres \
  psql -U dcms -d dcms < backend/migrate.sql

# MinIO bucket
docker compose -f docker-compose.prod.yml exec backend npm run init-bucket

# Seed (optional in prod — normally I create the first admin by hand)
docker compose -f docker-compose.prod.yml exec -T postgres \
  psql -U dcms -d dcms < backend/seed.sql
```

### 2.11 Backups

I add a host-level cron job (not inside a container):

```bash
# /etc/cron.d/dcms-backup
0 2 * * * root /opt/dcms/scripts/backup.sh
```

`/opt/dcms/scripts/backup.sh`:

```bash
#!/bin/bash
set -e
DATE=$(date +%Y%m%d-%H%M)
BACKUP_DIR=/var/backups/dcms
mkdir -p $BACKUP_DIR

# PG dump
docker compose -f /opt/dcms/docker-compose.prod.yml exec -T postgres \
  pg_dump -U dcms dcms | gzip > $BACKUP_DIR/db-$DATE.sql.gz

# MinIO: mirror to a remote bucket (or to a backup disk)
# docker run --rm --network dcms_default \
#   minio/mc:latest mirror local/dcms-files remote-backup/

# Retention: 30 days
find $BACKUP_DIR -name 'db-*.sql.gz' -mtime +30 -delete
```

### 2.12 Monitoring (minimum)

`docker compose logs -f` plus an external pinger (UptimeRobot, Pingdom) hitting `/health`. I add Prometheus + Grafana + Loki in a later sprint.

---

## 3. Kubernetes deployment

For multi-project / multi-tenant setups or once HA matters.

### 3.1 Namespace and secrets

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dcms
---
apiVersion: v1
kind: Secret
metadata:
  name: dcms-secrets
  namespace: dcms
type: Opaque
stringData:
  DB_PASSWORD: "REPLACE-ME-32-CHARS"
  JWT_SECRET:  "REPLACE-ME-32-CHARS"
  S3_ACCESS_KEY: "REPLACE-ME"
  S3_SECRET_KEY: "REPLACE-ME"
```

In production I source these from External Secrets + Vault or AWS Secrets Manager rather than committing them.

### 3.2 ConfigMap

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dcms-config
  namespace: dcms
data:
  DB_HOST: "postgres"
  DB_PORT: "5432"
  DB_USER: "dcms"
  DB_NAME: "dcms"
  S3_ENDPOINT: "http://minio:9000"
  S3_PUBLIC_ENDPOINT: "https://dcms.example.com/minio"
  S3_BUCKET: "dcms-files"
  S3_REGION: "us-east-1"
  S3_FORCE_PATH_STYLE: "true"
  PORT: "4000"
```

### 3.3 Postgres StatefulSet

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: dcms
spec:
  serviceName: postgres
  replicas: 1
  selector: { matchLabels: { app: postgres } }
  template:
    metadata: { labels: { app: postgres } }
    spec:
      containers:
        - name: postgres
          image: postgres:15-alpine
          ports:
            - containerPort: 5432
          envFrom:
            - configMapRef: { name: dcms-config }
            - secretRef:    { name: dcms-secrets }
          env:
            - name: POSTGRES_USER
              valueFrom: { configMapKeyRef: { name: dcms-config, key: DB_USER } }
            - name: POSTGRES_PASSWORD
              valueFrom: { secretKeyRef: { name: dcms-secrets, key: DB_PASSWORD } }
            - name: POSTGRES_DB
              valueFrom: { configMapKeyRef: { name: dcms-config, key: DB_NAME } }
          volumeMounts:
            - { name: data, mountPath: /var/lib/postgresql/data }
          readinessProbe:
            exec: { command: ["pg_isready", "-U", "dcms"] }
            periodSeconds: 10
  volumeClaimTemplates:
    - metadata: { name: data }
      spec:
        accessModes: ["ReadWriteOnce"]
        storageClassName: standard  # adjust for the cluster
        resources: { requests: { storage: 50Gi } }
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: dcms
spec:
  clusterIP: None    # headless
  selector: { app: postgres }
  ports: [{ port: 5432 }]
```

### 3.4 MinIO StatefulSet

If the cluster has access to a managed object store (AWS S3, etc.), I skip this entire section and just point `S3_ENDPOINT` at the managed endpoint. When I do self-host:

```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: { name: minio, namespace: dcms }
spec:
  serviceName: minio
  replicas: 1   # for HA I'd run 4-node distributed MinIO instead
  selector: { matchLabels: { app: minio } }
  template:
    metadata: { labels: { app: minio } }
    spec:
      containers:
        - name: minio
          image: minio/minio:latest
          args: ["server", "/data", "--console-address", ":9001"]
          env:
            - name: MINIO_ROOT_USER
              valueFrom: { secretKeyRef: { name: dcms-secrets, key: S3_ACCESS_KEY } }
            - name: MINIO_ROOT_PASSWORD
              valueFrom: { secretKeyRef: { name: dcms-secrets, key: S3_SECRET_KEY } }
          ports:
            - containerPort: 9000
            - containerPort: 9001
          volumeMounts:
            - { name: data, mountPath: /data }
  volumeClaimTemplates:
    - metadata: { name: data }
      spec:
        accessModes: ["ReadWriteOnce"]
        resources: { requests: { storage: 200Gi } }
---
apiVersion: v1
kind: Service
metadata: { name: minio, namespace: dcms }
spec:
  selector: { app: minio }
  ports:
    - { name: api, port: 9000, targetPort: 9000 }
    - { name: console, port: 9001, targetPort: 9001 }
```

### 3.5 Backend Deployment, Service, and HPA

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: backend, namespace: dcms }
spec:
  replicas: 3
  selector: { matchLabels: { app: backend } }
  template:
    metadata: { labels: { app: backend } }
    spec:
      containers:
        - name: backend
          image: registry.example.com/dcms-backend:${IMAGE_TAG}
          ports: [{ containerPort: 4000 }]
          envFrom:
            - configMapRef: { name: dcms-config }
            - secretRef:    { name: dcms-secrets }
          resources:
            requests: { cpu: 100m, memory: 256Mi }
            limits:   { cpu: 500m, memory: 512Mi }
          readinessProbe:
            httpGet: { path: /health, port: 4000 }
            periodSeconds: 5
          livenessProbe:
            httpGet: { path: /health, port: 4000 }
            periodSeconds: 30
---
apiVersion: v1
kind: Service
metadata: { name: backend, namespace: dcms }
spec:
  selector: { app: backend }
  ports: [{ port: 4000, targetPort: 4000 }]
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: backend, namespace: dcms }
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: backend
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource: { name: cpu, target: { type: Utilization, averageUtilization: 70 } }
```

### 3.6 Frontend Deployment and Service

```yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: frontend, namespace: dcms }
spec:
  replicas: 2
  selector: { matchLabels: { app: frontend } }
  template:
    metadata: { labels: { app: frontend } }
    spec:
      containers:
        - name: frontend
          image: registry.example.com/dcms-frontend:${IMAGE_TAG}
          ports: [{ containerPort: 80 }]
          resources:
            requests: { cpu: 50m, memory: 64Mi }
            limits:   { cpu: 200m, memory: 128Mi }
---
apiVersion: v1
kind: Service
metadata: { name: frontend, namespace: dcms }
spec:
  selector: { app: frontend }
  ports: [{ port: 80 }]
```

### 3.7 Ingress with cert-manager

```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata: { name: letsencrypt-prod }
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@example.com
    privateKeySecretRef: { name: letsencrypt-prod-key }
    solvers:
      - http01: { ingress: { class: nginx } }
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: dcms
  namespace: dcms
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/proxy-body-size: "200m"
    nginx.ingress.kubernetes.io/proxy-request-buffering: "off"
    nginx.ingress.kubernetes.io/limit-rps: "10"
spec:
  ingressClassName: nginx
  tls:
    - hosts: [dcms.example.com]
      secretName: dcms-tls
  rules:
    - host: dcms.example.com
      http:
        paths:
          - path: /api
            pathType: Prefix
            backend: { service: { name: backend,  port: { number: 4000 } } }
          - path: /minio
            pathType: Prefix
            backend: { service: { name: minio,    port: { number: 9000 } } }
          - path: /
            pathType: Prefix
            backend: { service: { name: frontend, port: { number: 80 } } }
```

### 3.8 NetworkPolicy

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: backend-only, namespace: dcms }
spec:
  podSelector: { matchLabels: { app: postgres } }
  policyTypes: [Ingress]
  ingress:
    - from:
        - podSelector: { matchLabels: { app: backend } }
      ports: [{ protocol: TCP, port: 5432 }]
```

Postgres only accepts traffic from backend pods, blocking lateral access from anything else in the cluster.

### 3.9 Apply order

```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/secrets.yaml         # via sealed-secrets or ESO in real prod
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/postgres.yaml
kubectl apply -f k8s/minio.yaml
kubectl apply -f k8s/backend.yaml
kubectl apply -f k8s/frontend.yaml
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/network-policies.yaml

# Database migration as a Job — cleaner than kubectl exec
kubectl apply -f k8s/jobs/migrate.yaml
```

`k8s/jobs/migrate.yaml`:

```yaml
apiVersion: batch/v1
kind: Job
metadata: { name: migrate, namespace: dcms }
spec:
  template:
    spec:
      restartPolicy: OnFailure
      containers:
        - name: migrate
          image: registry.example.com/dcms-backend:${IMAGE_TAG}
          command: ["sh", "-c"]
          args:
            - |
              apk add --no-cache postgresql-client
              psql "host=$DB_HOST port=$DB_PORT user=$DB_USER password=$DB_PASSWORD dbname=$DB_NAME" \
                < /app/migrate.sql
          envFrom:
            - configMapRef: { name: dcms-config }
            - secretRef:    { name: dcms-secrets }
```

---

## 4. CI/CD — GitHub Actions

`.github/workflows/build.yml`:

```yaml
name: Build and deploy

on:
  push:
    branches: [main]
    tags: ['v*']

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set image tag
        id: tag
        run: echo "tag=$(git rev-parse --short HEAD)" >> $GITHUB_OUTPUT

      - name: Log in to registry
        uses: docker/login-action@v3
        with:
          registry: registry.example.com
          username: ${{ secrets.REGISTRY_USER }}
          password: ${{ secrets.REGISTRY_PASSWORD }}

      - name: Build backend
        uses: docker/build-push-action@v5
        with:
          context: ./backend
          push: true
          tags: |
            registry.example.com/dcms-backend:${{ steps.tag.outputs.tag }}
            registry.example.com/dcms-backend:latest

      - name: Build frontend
        uses: docker/build-push-action@v5
        with:
          context: ./frontend
          push: true
          tags: |
            registry.example.com/dcms-frontend:${{ steps.tag.outputs.tag }}
            registry.example.com/dcms-frontend:latest

  deploy:
    needs: build
    if: startsWith(github.ref, 'refs/tags/v')
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Configure kubectl
        run: |
          mkdir -p ~/.kube
          echo "${{ secrets.KUBECONFIG }}" > ~/.kube/config
      - name: Roll out new image
        run: |
          TAG=${GITHUB_REF#refs/tags/v}
          kubectl -n dcms set image deploy/backend  backend=registry.example.com/dcms-backend:$TAG
          kubectl -n dcms set image deploy/frontend frontend=registry.example.com/dcms-frontend:$TAG
          kubectl -n dcms rollout status deploy/backend
          kubectl -n dcms rollout status deploy/frontend
```

---

## 5. Production checklist

### 5.1 Security

- [ ] Every secret comes from a secret manager (Vault / AWS SM / GCP SM); none live in git
- [ ] DB password, JWT secret, and MinIO root key are each ≥ 32 chars and **distinct**
- [ ] Postgres port 5432 is not exposed publicly; only the backend can reach it
- [ ] MinIO console (9001) is restricted to internal IPs
- [ ] HSTS is on
- [ ] Upload and download endpoints are rate-limited
- [ ] CORS allowlist contains only the production frontend domain
- [ ] JWT lifetime ≤ 12 hours, with a refresh-token flow
- [ ] CSP headers are restrictive (`script-src 'self'`, etc.)

### 5.2 Backup and recovery

- [ ] Daily `pg_dump` plus continuous WAL archiving (`archive_command`)
- [ ] MinIO objects mirrored offsite via `mc mirror` or lifecycle policy
- [ ] 30-day retention; one snapshot per month archived; one snapshot per year retained
- [ ] **A restore actually rehearsed** — backups that can't be restored aren't backups

### 5.3 Monitoring and alerts

- [ ] `/health` polled by an external uptime check
- [ ] PG slow query log on (`log_min_duration_statement = 1000`)
- [ ] Disk-usage > 80 % alerts
- [ ] API 5xx rate > 1 % alerts
- [ ] Sentry (or equivalent) catching backend unhandled exceptions and frontend JS errors
- [ ] Audit log shipped to an external store (so an intruder can't cover their tracks by wiping it)

### 5.4 Disaster recovery

- [ ] Single-server: a cold standby in the same region, daily backup replay
- [ ] Kubernetes: cross-AZ scheduling; Postgres via patroni or managed RDS multi-AZ; MinIO in distributed mode or replaced by cloud object storage

### 5.5 Performance baselines

I record these on first cutover so I have something to compare against later:

- API p50 / p95 / p99 latency
- DB connection pool utilization
- End-to-end time to upload a 100 MB file
- Document list query (200 rows) latency
- Concurrent user count

### 5.6 Capacity guidance

| Scale | Documents | Concurrent users | API replicas | Postgres | MinIO |
|---|---|---|---|---|---|
| Single project, < 50 users | < 5k | < 20 | 1 – 2 | single node, 2 vCPU / 4 GB | 100 GB |
| Mid, 50 – 200 users | 5k – 50k | 20 – 80 | 3 – 5 | primary + replica, 4 vCPU / 16 GB | 1 TB |
| Large / multi-project | > 50k | > 80 | 5+ (HPA) | primary + replicas | distributed MinIO or cloud OSS |

---

## 6. Cutover notes

The bugs I expect to hit on first production cutover:

1. **TLS certificate doesn't take effect.** Wrong cert path, ACME challenge fails, or firewall blocks port 80. I run a staging cert first to confirm the flow before going live.
2. **Presigned URLs 404 in the browser.** Means `S3_PUBLIC_ENDPOINT` points at the internal Docker hostname instead of the public URL the browser can resolve.
3. **JWTs validate intermittently.** Multiple backend pods running with different `JWT_SECRET` values — a token signed on pod A fails on pod B. The secret must be shared.
4. **Seed doesn't run after upgrade.** Docker Compose's `init-scripts` only run when the data volume is empty; if I keep the volume across upgrades I run `psql` by hand.
5. **MinIO bucket name rejected.** Uppercase, underscores, or excessive length all fail. Lowercase alphanumeric plus hyphens only.
6. **Nginx `client_max_body_size` forgotten.** Frontend reports 413 because the default is 1 MB.

My checklist for every release:

1. CI green (unit tests + lint + build)
2. Canary to staging, end-to-end smoke test
3. Rollback plan confirmed — `kubectl rollout undo deploy/backend` is one command
4. Deploy, watch error rate for 15 minutes, only then call it done
