// DCMS v1 — SSO via OIDC
// DCMS never sees a password. The IdP authenticates; we issue our own short-lived JWT
// after a successful exchange, and track the session in user_sessions so logout works.

const { Issuer, generators } = require('openid-client');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const JWT_SECRET   = process.env.JWT_SECRET;
const JWT_EXPIRES  = process.env.JWT_EXPIRES || '12h';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

const ISSUER_URL    = process.env.OIDC_ISSUER_URL;
const CLIENT_ID     = process.env.OIDC_CLIENT_ID;
const CLIENT_SECRET = process.env.OIDC_CLIENT_SECRET;
const REDIRECT_URI  = process.env.OIDC_REDIRECT_URI;
const SCOPES        = process.env.OIDC_SCOPES || 'openid email profile';
const HOSTED_DOMAIN = process.env.OIDC_HOSTED_DOMAIN;   // Google only

let client;

async function init() {
  if (!ISSUER_URL) {
    console.warn('OIDC not configured — SSO disabled. Set OIDC_ISSUER_URL to enable.');
    return null;
  }
  try {
    const issuer = await Issuer.discover(ISSUER_URL);
    client = new issuer.Client({
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uris: [REDIRECT_URI],
      response_types: ['code'],
    });
    console.log(`OIDC initialized — issuer ${issuer.metadata.issuer}`);
    return client;
  } catch (e) {
    console.error('OIDC init failed:', e.message);
    return null;
  }
}

function isEnabled() {
  return !!client;
}

function startAuth(req, res) {
  if (!client) {
    return res.status(503).json({ code: 50301, message: 'SSO not configured' });
  }

  const state = generators.state();
  const nonce = generators.nonce();
  const codeVerifier = generators.codeVerifier();
  const codeChallenge = generators.codeChallenge(codeVerifier);

  const cookieOpts = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 10 * 60 * 1000,
    path: '/api/v1/auth/sso',
  };
  res.cookie('sso_state', state, cookieOpts);
  res.cookie('sso_nonce', nonce, cookieOpts);
  res.cookie('sso_pkce', codeVerifier, cookieOpts);

  const redirectTo = req.query.redirect_to || '/';
  res.cookie('sso_return', redirectTo, cookieOpts);

  const params = {
    scope: SCOPES,
    state,
    nonce,
    code_challenge: codeChallenge,
    code_challenge_method: 'S256',
  };
  if (HOSTED_DOMAIN) params.hd = HOSTED_DOMAIN;

  res.redirect(client.authorizationUrl(params));
}

async function handleCallback(req, res, pool, audit) {
  if (!client) return res.status(503).send('SSO not configured');

  const { sso_state, sso_nonce, sso_pkce, sso_return } = req.cookies || {};
  if (!sso_state || !sso_nonce || !sso_pkce) {
    return res.status(400).send('SSO flow expired — please try signing in again.');
  }

  // Clear the temporary cookies regardless of outcome
  const clearOpts = { path: '/api/v1/auth/sso' };
  res.clearCookie('sso_state', clearOpts);
  res.clearCookie('sso_nonce', clearOpts);
  res.clearCookie('sso_pkce', clearOpts);
  res.clearCookie('sso_return', clearOpts);

  const params = client.callbackParams(req);

  let tokenSet, userinfo;
  try {
    tokenSet = await client.callback(REDIRECT_URI, params, {
      state: sso_state,
      nonce: sso_nonce,
      code_verifier: sso_pkce,
    });
    userinfo = await client.userinfo(tokenSet.access_token);
  } catch (e) {
    console.error('OIDC callback error:', e.message);
    return res.status(401).send('SSO authentication failed.');
  }

  if (HOSTED_DOMAIN && userinfo.hd !== HOSTED_DOMAIN) {
    return res.status(403).send('Sign-in is restricted to authorized domains.');
  }
  if (userinfo.email_verified === false) {
    return res.status(403).send('Email not verified at the identity provider.');
  }

  const user = await findOrCreateUser(pool, {
    provider: ISSUER_URL,
    subject: userinfo.sub,
    email: userinfo.email,
    name: userinfo.name || userinfo.preferred_username || userinfo.email,
  });

  const tokenId = crypto.randomUUID();
  const dcmsToken = jwt.sign(
    { id: user.id, email: user.email, name: user.name, role: user.default_role, jti: tokenId },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );

  const expiresAt = new Date(Date.now() + parseExpiry(JWT_EXPIRES));
  await pool.query(
    `INSERT INTO user_sessions (user_id, token_id, expires_at, ip_address, user_agent)
     VALUES ($1, $2, $3, $4, $5)`,
    [user.id, tokenId, expiresAt, req.ip, req.get('user-agent') || null]
  );

  await audit(user.id, 'user.login.sso', 'user', user.id,
              { provider: ISSUER_URL, subject: userinfo.sub });
  await pool.query('UPDATE users SET last_login_at=now() WHERE id=$1', [user.id]);

  res.cookie('dcms_token', dcmsToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: parseExpiry(JWT_EXPIRES),
    path: '/',
  });

  res.redirect(`${FRONTEND_URL}${sso_return || '/'}`);
}

// 1) Match by (provider, subject); 2) by email; 3) create
async function findOrCreateUser(pool, { provider, subject, email, name }) {
  let r = await pool.query(
    'SELECT * FROM users WHERE sso_provider=$1 AND sso_subject=$2',
    [provider, subject]
  );
  if (r.rows.length) return r.rows[0];

  r = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  if (r.rows.length) {
    await pool.query(
      'UPDATE users SET sso_provider=$1, sso_subject=$2 WHERE id=$3',
      [provider, subject, r.rows[0].id]
    );
    return r.rows[0];
  }

  const created = (await pool.query(
    `INSERT INTO users (email, name, password_hash, default_role, sso_provider, sso_subject)
     VALUES ($1, $2, NULL, 'member', $3, $4)
     RETURNING *`,
    [email, name, provider, subject]
  )).rows[0];
  return created;
}

function parseExpiry(s) {
  const m = /^(\d+)([smhd])$/.exec(s || '');
  if (!m) return 12 * 3600 * 1000;
  const [, n, unit] = m;
  const mult = { s: 1e3, m: 60e3, h: 3600e3, d: 86400e3 }[unit];
  return Number(n) * mult;
}

async function logout(req, res, pool, audit) {
  const token = req.cookies?.dcms_token
    || (req.headers.authorization || '').replace(/^Bearer /, '');
  if (token) {
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (payload.jti) {
        await pool.query(
          'UPDATE user_sessions SET revoked_at=now() WHERE token_id=$1',
          [payload.jti]
        );
      }
      if (payload.id) await audit(payload.id, 'user.logout', 'user', payload.id);
    } catch {
      // Token already invalid — clearing the cookie is enough.
    }
  }
  res.clearCookie('dcms_token', { path: '/' });
  res.json({ code: 0, data: { ok: true } });
}

module.exports = {
  init, isEnabled, startAuth, handleCallback, logout,
  parseExpiry,
};
