// DCMS v1 — workflow engine
// Instantiates a workflow from a template, resolves abstract roles into concrete
// user_ids, advances on approve, restarts on reject, holds on comment.

const VERSION_TO_INREVIEW =
  "UPDATE document_versions SET status='in_review' WHERE id=$1";
const VERSION_TO_DRAFT =
  "UPDATE document_versions SET status='draft' WHERE id=$1";
const VERSION_TO_FINAL =
  "UPDATE document_versions SET status=$2, " +
  "issued_at = CASE WHEN $2='issued' THEN now() ELSE issued_at END " +
  "WHERE id=$1";

// Resolve an abstract role into a concrete user_id.
// 1) exact (project, role, discipline) → win
// 2) project-wide (discipline IS NULL) → fall back
// 3) nothing → null (the step stays unassigned, admin gets notified)
async function resolveAssignee(client, { projectId, role, discipline }) {
  let r = await client.query(
    `SELECT user_id FROM project_role_assignments
     WHERE project_id=$1 AND role_in_workflow=$2 AND discipline=$3
     ORDER BY priority LIMIT 1`,
    [projectId, role, discipline]
  );
  if (r.rows.length) return r.rows[0].user_id;
  r = await client.query(
    `SELECT user_id FROM project_role_assignments
     WHERE project_id=$1 AND role_in_workflow=$2 AND discipline IS NULL
     ORDER BY priority LIMIT 1`,
    [projectId, role]
  );
  return r.rows[0]?.user_id || null;
}

// Pick a template. explicit > applies_to match > standard_review fallback.
async function pickTemplate(client, { source, doc_type, explicit }) {
  if (explicit) {
    const r = await client.query(
      'SELECT * FROM workflow_templates WHERE template_code=$1 AND is_active=true',
      [explicit]
    );
    if (r.rows.length) return r.rows[0];
  }
  const all = (await client.query(
    'SELECT * FROM workflow_templates WHERE is_active=true'
  )).rows;
  for (const t of all) {
    const a = t.applies_to || {};
    const sourceOk = !a.source || a.source === source;
    const typeOk = !a.doc_type
      || (Array.isArray(a.doc_type) && a.doc_type.includes(doc_type));
    if (sourceOk && typeOk && (a.source || a.doc_type)) return t;
  }
  return all.find((t) => t.template_code === 'standard_review') || all[0];
}

// Instantiate a workflow on a draft version. Caller must wrap in a transaction.
async function instantiate(client, { versionId, explicit }) {
  const ctx = (await client.query(
    `SELECT dv.id AS version_id, dv.status AS version_status,
            d.id AS document_id, d.project_id, d.discipline, d.doc_type, d.source
     FROM document_versions dv JOIN documents d ON d.id=dv.document_id
     WHERE dv.id=$1`,
    [versionId]
  )).rows[0];
  if (!ctx) throw new Error('Version not found');
  if (ctx.version_status !== 'draft') {
    throw new Error(`Cannot start workflow on status=${ctx.version_status}`);
  }

  const tpl = await pickTemplate(client, {
    source: ctx.source, doc_type: ctx.doc_type, explicit,
  });
  if (!tpl) throw new Error('No applicable workflow template');

  const tplSteps = (await client.query(
    'SELECT * FROM workflow_template_steps WHERE template_code=$1 ORDER BY sequence',
    [tpl.template_code]
  )).rows;
  if (!tplSteps.length) throw new Error('Template has no steps');

  const inst = (await client.query(
    `INSERT INTO workflow_instances
       (document_version_id, template_code, current_step, current_step_sequence, status, started_at)
     VALUES ($1, $2, $3, 1, 'in_progress', now())
     RETURNING *`,
    [versionId, tpl.template_code, tplSteps[0].step_name]
  )).rows[0];

  for (const s of tplSteps) {
    const isFirst = s.sequence === 1;
    const assignee = isFirst
      ? await resolveAssignee(client, {
          projectId: ctx.project_id,
          role: s.assignee_role,
          discipline: ctx.discipline,
        })
      : null;
    const dueAt = isFirst && s.sla_days
      ? new Date(Date.now() + s.sla_days * 86400000)
      : null;
    await client.query(
      `INSERT INTO workflow_steps
        (instance_id, step_name, sequence, assignee_id, assignee_role, due_at, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [inst.id, s.step_name, s.sequence, assignee, s.assignee_role, dueAt,
       isFirst ? 'active' : 'pending']
    );
  }

  await client.query(VERSION_TO_INREVIEW, [versionId]);
  return inst;
}

// Complete one step. Caller must wrap in a transaction.
async function completeStep(client, { stepId, action, comment, userId }) {
  const step = (await client.query(
    `SELECT ws.*, wi.id AS instance_id, wi.template_code,
            wi.current_step_sequence, dv.id AS version_id, dv.document_id,
            d.project_id, d.discipline, d.doc_type
     FROM workflow_steps ws
     JOIN workflow_instances wi ON wi.id=ws.instance_id
     JOIN document_versions dv ON dv.id=wi.document_version_id
     JOIN documents d ON d.id=dv.document_id
     WHERE ws.id=$1`,
    [stepId]
  )).rows[0];
  if (!step) throw new Error('Step not found');
  if (step.status !== 'active') throw new Error(`Step is ${step.status}, not active`);
  if (step.assignee_id !== userId) {
    throw new Error('Only the assignee can complete this step');
  }
  if (!['approved', 'rejected', 'commented'].includes(action)) {
    throw new Error('action must be approved | rejected | commented');
  }

  // Comment: log against the audit and leave the step active.
  if (action === 'commented') {
    await client.query(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, detail)
       VALUES ($1,'workflow.comment','workflow_step',$2,$3)`,
      [userId, stepId, JSON.stringify({ comment })]
    );
    return { advanced: false };
  }

  await client.query(
    `UPDATE workflow_steps
     SET status='completed', completed_at=now(), action=$1, comment=$2, completed_by=$3
     WHERE id=$4`,
    [action, comment || null, userId, stepId]
  );

  if (action === 'rejected') {
    await client.query(
      `UPDATE workflow_instances SET status='cancelled', completed_at=now() WHERE id=$1`,
      [step.instance_id]
    );
    await client.query(VERSION_TO_DRAFT, [step.version_id]);
    return { advanced: false, rejected: true, version_id: step.version_id };
  }

  const next = (await client.query(
    `SELECT * FROM workflow_steps
     WHERE instance_id=$1 AND sequence>$2
     ORDER BY sequence LIMIT 1`,
    [step.instance_id, step.sequence]
  )).rows[0];

  if (!next) {
    const tpl = (await client.query(
      `SELECT final_status_on_complete FROM workflow_templates WHERE template_code=$1`,
      [step.template_code]
    )).rows[0];
    await client.query(
      `UPDATE workflow_instances
       SET status='completed', completed_at=now(), current_step=NULL, current_step_sequence=NULL
       WHERE id=$1`,
      [step.instance_id]
    );
    await client.query(VERSION_TO_FINAL, [step.version_id, tpl.final_status_on_complete]);
    return {
      advanced: true, completed: true,
      final_status: tpl.final_status_on_complete,
      version_id: step.version_id,
    };
  }

  const assignee = await resolveAssignee(client, {
    projectId: step.project_id,
    role: next.assignee_role,
    discipline: step.discipline,
  });
  const tplStep = (await client.query(
    `SELECT sla_days FROM workflow_template_steps WHERE template_code=$1 AND sequence=$2`,
    [step.template_code, next.sequence]
  )).rows[0];
  const dueAt = tplStep?.sla_days
    ? new Date(Date.now() + tplStep.sla_days * 86400000)
    : null;

  await client.query(
    `UPDATE workflow_steps
     SET status='active', assignee_id=$1, due_at=$2
     WHERE id=$3`,
    [assignee, dueAt, next.id]
  );
  await client.query(
    `UPDATE workflow_instances SET current_step=$1, current_step_sequence=$2 WHERE id=$3`,
    [next.step_name, next.sequence, step.instance_id]
  );

  return {
    advanced: true,
    next_step: next.step_name,
    next_assignee: assignee,
    version_id: step.version_id,
  };
}

async function getMyPendingSteps(client, userId) {
  return (await client.query(
    `SELECT ws.id AS step_id, ws.step_name, ws.due_at,
            wi.template_code, wi.id AS instance_id,
            dv.id AS version_id, dv.revision,
            d.id AS document_id, d.doc_code, d.title, d.discipline, d.doc_type,
            p.id AS project_id, p.code AS project_code, p.name AS project_name
     FROM workflow_steps ws
     JOIN workflow_instances wi ON wi.id=ws.instance_id
     JOIN document_versions dv ON dv.id=wi.document_version_id
     JOIN documents d ON d.id=dv.document_id
     JOIN projects p ON p.id=d.project_id
     WHERE ws.assignee_id=$1 AND ws.status='active'
     ORDER BY ws.due_at NULLS LAST, ws.due_at ASC`,
    [userId]
  )).rows;
}

async function getInstanceForVersion(client, versionId) {
  const inst = (await client.query(
    `SELECT wi.*, wt.name AS template_name
     FROM workflow_instances wi
     LEFT JOIN workflow_templates wt ON wt.template_code=wi.template_code
     WHERE wi.document_version_id=$1
     ORDER BY wi.started_at DESC LIMIT 1`,
    [versionId]
  )).rows[0];
  if (!inst) return null;
  const steps = (await client.query(
    `SELECT ws.*, u.name AS assignee_name
     FROM workflow_steps ws
     LEFT JOIN users u ON u.id=ws.assignee_id
     WHERE ws.instance_id=$1 ORDER BY ws.sequence`,
    [inst.id]
  )).rows;
  return { ...inst, steps };
}

module.exports = {
  instantiate,
  completeStep,
  getMyPendingSteps,
  getInstanceForVersion,
};
