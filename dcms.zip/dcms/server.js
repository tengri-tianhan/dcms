// DCMS v1 — single-file Express backend.
// Covers everything from the MVP plus: presigned URL storage, workflow engine,
// OIDC SSO, Elasticsearch search, session-aware auth middleware.

const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const storage = require('./lib/storage');
const wf      = require('./lib/workflow');
const sso     = require('./lib/sso');
const search  = require('./lib/search');

const JWT_SECRET  = process.env.JWT_SECRET || 'dev-secret-change-me-32-chars-min';
const JWT_EXPIRES = process.env.JWT_EXPIRES || '12h';
const ALLOW_PASSWORD_LOGIN = process.env.ALLOW_PASSWORD_LOGIN === 'true';
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || 'dcms',
  password: process.env.DB_PASSWORD || 'dcms_pw',
  database: process.env.DB_NAME || 'dcms',
});

const app = express();
app.use(cors({ origin: FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// ============================================================================
// Helpers
// ============================================================================
const ok  = (res, data) => res.json({ code: 0, data });
const err = (res, status, code, message) => res.status(status).json({ code, message });

const r = (fn) => (req, res) => fn(req, res).catch((e) => {
  console.error('route error:', e);
  if (e.code === '23505') return err(res, 409, 40901, 'Duplicate');
  if (e.code === '23503') return err(res, 400, 40001, 'Foreign key violation');
  err(res, 500, 50001, 'Internal error');
});

async function audit(userId, action, entityType, entityId, detail) {
  try {
    await pool.query(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, detail)
       VALUES ($1,$2,$3,$4,$5)`,
      [userId, action, entityType, entityId, detail || null]
    );
  } catch (e) {
    console.error('audit failed:', e.message);
  }
}

async function nextDocSeq(projectId, disc, type) {
  const r = await pool.query(
    `SELECT doc_code FROM documents
     WHERE project_id=$1 AND discipline=$2 AND doc_type=$3
     ORDER BY doc_code DESC LIMIT 1`,
    [projectId, disc, type]
  );
  if (!r.rows.length) return 1;
  const m = r.rows[0].doc_code.match(/-(\d+)$/);
  return m ? parseInt(m[1], 10) + 1 : 1;
}

// Build the denormalized ES document for a given documents.id and push it.
// Called after every write that affects searchable state.
async function searchUpsertById(documentId) {
  const r = await pool.query(
    `SELECT d.id, d.project_id, d.doc_code, d.title, d.discipline, d.doc_type,
            d.source, d.created_at, d.updated_at,
            v.status AS current_status, v.revision AS current_revision
     FROM documents d
     LEFT JOIN document_versions v ON v.id = d.current_version_id
     WHERE d.id=$1 AND d.deleted_at IS NULL`,
    [documentId]
  );
  if (!r.rows.length) {
    await search.remove(documentId);
    return;
  }
  await search.upsert(r.rows[0]);
}

// ============================================================================
// Auth middleware — JWT + session validity
// ============================================================================
async function authMiddleware(req, res, next) {
  const token = req.cookies?.dcms_token
    || (req.headers.authorization || '').replace(/^Bearer /, '');
  if (!token) return err(res, 401, 40101, 'Missing token');

  let payload;
  try { payload = jwt.verify(token, JWT_SECRET); }
  catch { return err(res, 401, 40101, 'Invalid token'); }

  // If the token has a jti, check the session table — supports revocation
  if (payload.jti) {
    const s = (await pool.query(
      'SELECT revoked_at, expires_at FROM user_sessions WHERE token_id=$1',
      [payload.jti]
    )).rows[0];
    if (!s || s.revoked_at || s.expires_at < new Date()) {
      return err(res, 401, 40101, 'Session expired or revoked');
    }
  }

  req.user = payload;
  next();
}

// ============================================================================
// Auth — providers, password login (gated), SSO start/callback, logout, me
// ============================================================================
app.get('/api/v1/auth/providers', (req, res) => {
  ok(res, {
    sso: sso.isEnabled(),
    sso_label: process.env.OIDC_PROVIDER_LABEL || 'Single sign-on',
    password: ALLOW_PASSWORD_LOGIN,
  });
});

app.post('/api/v1/auth/login', r(async (req, res) => {
  if (!ALLOW_PASSWORD_LOGIN) {
    return err(res, 403, 40301, 'Password login disabled — use SSO');
  }
  const { email, password } = req.body || {};
  if (!email || !password) return err(res, 400, 40001, 'email and password required');

  const u = (await pool.query(
    'SELECT * FROM users WHERE email=$1 AND is_active=true', [email]
  )).rows[0];
  if (!u || !u.password_hash) return err(res, 401, 40101, 'Invalid credentials');
  if (!bcrypt.compareSync(password, u.password_hash)) {
    return err(res, 401, 40101, 'Invalid credentials');
  }

  // Issue a session-tracked JWT (same shape as SSO so logout works uniformly)
  const tokenId = require('crypto').randomUUID();
  const token = jwt.sign(
    { id: u.id, email: u.email, name: u.name, role: u.default_role, jti: tokenId },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
  const expiresAt = new Date(Date.now() + sso.parseExpiry(JWT_EXPIRES));
  await pool.query(
    `INSERT INTO user_sessions (user_id, token_id, expires_at, ip_address, user_agent)
     VALUES ($1, $2, $3, $4, $5)`,
    [u.id, tokenId, expiresAt, req.ip, req.get('user-agent') || null]
  );

  res.cookie('dcms_token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: sso.parseExpiry(JWT_EXPIRES),
    path: '/',
  });
  await pool.query('UPDATE users SET last_login_at=now() WHERE id=$1', [u.id]);
  await audit(u.id, 'user.login.password', 'user', u.id);

  ok(res, {
    token,   // also return in body so non-cookie clients (CLI, tests) work
    user: { id: u.id, email: u.email, name: u.name, role: u.default_role },
  });
}));

app.get('/api/v1/auth/sso/start', (req, res) => sso.startAuth(req, res));
app.get('/api/v1/auth/sso/callback', (req, res) =>
  sso.handleCallback(req, res, pool, audit)
);

app.post('/api/v1/auth/logout', (req, res) => sso.logout(req, res, pool, audit));

app.get('/api/v1/auth/me', authMiddleware, r(async (req, res) => {
  const u = (await pool.query(
    'SELECT id, email, name, default_role FROM users WHERE id=$1', [req.user.id]
  )).rows[0];
  if (!u) return err(res, 404, 40401, 'User not found');
  const projects = (await pool.query(
    `SELECT p.*, m.role FROM projects p
     JOIN project_members m ON m.project_id=p.id
     WHERE m.user_id=$1 AND p.deleted_at IS NULL
     ORDER BY p.created_at DESC`,
    [req.user.id]
  )).rows;
  ok(res, { user: { ...u, role: u.default_role }, projects });
}));

// ============================================================================
// Projects + members
// ============================================================================
app.get('/api/v1/projects', authMiddleware, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT p.*, m.role FROM projects p
     JOIN project_members m ON m.project_id=p.id
     WHERE m.user_id=$1 AND p.deleted_at IS NULL
     ORDER BY p.created_at DESC`,
    [req.user.id]
  )).rows;
  ok(res, rows);
}));

app.get('/api/v1/projects/:id/members', authMiddleware, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT u.id, u.name, u.email, m.role, m.discipline
     FROM project_members m JOIN users u ON u.id=m.user_id
     WHERE m.project_id=$1 ORDER BY u.name`,
    [req.params.id]
  )).rows;
  ok(res, rows);
}));

// ============================================================================
// Documents
// ============================================================================
app.get('/api/v1/projects/:pid/documents', authMiddleware, r(async (req, res) => {
  const { discipline, doc_type, status } = req.query;
  const conds = ['d.project_id=$1', 'd.deleted_at IS NULL'];
  const args = [req.params.pid];
  if (discipline) { args.push(discipline); conds.push(`d.discipline=$${args.length}`); }
  if (doc_type)   { args.push(doc_type);   conds.push(`d.doc_type=$${args.length}`); }
  let sql = `SELECT d.*, v.revision AS current_revision, v.status AS current_status
             FROM documents d
             LEFT JOIN document_versions v ON v.id=d.current_version_id
             WHERE ${conds.join(' AND ')}`;
  if (status) { args.push(status); sql += ` AND v.status=$${args.length}`; }
  sql += ' ORDER BY d.created_at DESC LIMIT 200';
  ok(res, (await pool.query(sql, args)).rows);
}));

// Search via Elasticsearch (replaces MVP's ILIKE).
app.get('/api/v1/projects/:pid/documents/search', authMiddleware, r(async (req, res) => {
  const { q, discipline, doc_type, source, status, page, page_size } = req.query;
  const result = await search.search({
    projectId: req.params.pid,
    q: q || '',
    filters: { discipline, doc_type, source, current_status: status },
    page: Number(page) || 1,
    pageSize: Math.min(Number(page_size) || 20, 100),
  });
  ok(res, result);
}));

app.post('/api/v1/projects/:pid/documents', authMiddleware, r(async (req, res) => {
  const { title, discipline, doc_type, source } = req.body || {};
  if (!title || !discipline || !doc_type) {
    return err(res, 400, 40001, 'title, discipline, doc_type required');
  }
  const proj = (await pool.query('SELECT code FROM projects WHERE id=$1', [req.params.pid])).rows[0];
  if (!proj) return err(res, 404, 40401, 'Project not found');
  const seq = await nextDocSeq(req.params.pid, discipline, doc_type);
  const docCode = `${proj.code}-${discipline}-${doc_type}-${String(seq).padStart(3, '0')}`;
  const row = (await pool.query(
    `INSERT INTO documents (project_id, doc_code, title, discipline, doc_type, source, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.params.pid, docCode, title, discipline, doc_type, source || 'design', req.user.id]
  )).rows[0];
  await audit(req.user.id, 'document.create', 'document', row.id, { doc_code: docCode });
  await searchUpsertById(row.id);
  ok(res, row);
}));

app.get('/api/v1/documents/:id', authMiddleware, r(async (req, res) => {
  const d = (await pool.query(
    'SELECT * FROM documents WHERE id=$1 AND deleted_at IS NULL', [req.params.id]
  )).rows[0];
  if (!d) return err(res, 404, 40401, 'Not found');
  const versions = (await pool.query(
    `SELECT v.*, u.name AS created_by_name
     FROM document_versions v JOIN users u ON u.id=v.created_by
     WHERE v.document_id=$1 ORDER BY v.created_at DESC`,
    [req.params.id]
  )).rows;
  ok(res, { ...d, versions });
}));

app.delete('/api/v1/documents/:id', authMiddleware, r(async (req, res) => {
  await pool.query(
    'UPDATE documents SET deleted_at=now() WHERE id=$1 AND deleted_at IS NULL',
    [req.params.id]
  );
  await audit(req.user.id, 'document.delete', 'document', req.params.id);
  await search.remove(req.params.id);
  ok(res, { id: req.params.id });
}));

// ============================================================================
// Versions — two-phase upload (init-upload → PUT to S3 → register)
// ============================================================================
app.post('/api/v1/documents/:id/versions/init-upload', authMiddleware, r(async (req, res) => {
  const { file_name, mime_type, file_size } = req.body || {};
  if (!file_name || !mime_type || !file_size) {
    return err(res, 400, 40001, 'file_name, mime_type, file_size required');
  }
  if (file_size > 200 * 1024 * 1024) {
    return err(res, 400, 40001, 'File too large (200 MB max)');
  }
  const d = (await pool.query(
    'SELECT id FROM documents WHERE id=$1 AND deleted_at IS NULL',
    [req.params.id]
  )).rows[0];
  if (!d) return err(res, 404, 40401, 'Document not found');

  const fileKey = storage.buildFileKey(req.params.id, file_name);
  const uploadUrl = await storage.presignedPut({ fileKey, mimeType: mime_type });

  ok(res, { file_key: fileKey, upload_url: uploadUrl, expires_in: 600 });
}));

app.post('/api/v1/documents/:id/versions', authMiddleware, r(async (req, res) => {
  const { revision, file_key, file_name, file_size, mime_type,
          checksum_sha256, change_note } = req.body || {};
  if (!revision || !file_key || !file_name || !file_size
      || !mime_type || !checksum_sha256 || !change_note) {
    return err(res, 400, 40001,
      'revision, file_key, file_name, file_size, mime_type, ' +
      'checksum_sha256, change_note required');
  }

  // Verify the object actually landed in storage with the expected size
  const head = await storage.getObjectHead(file_key).catch(() => null);
  if (!head) return err(res, 400, 40001, 'Upload not found on storage');
  if (head.size !== Number(file_size)) {
    return err(res, 400, 40001, 'File size mismatch');
  }

  try {
    const row = (await pool.query(
      `INSERT INTO document_versions
        (document_id, revision, status, file_key, file_name, file_size,
         mime_type, checksum_sha256, change_note, created_by)
       VALUES ($1,$2,'draft',$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.params.id, revision, file_key, file_name, file_size,
       mime_type, checksum_sha256, change_note, req.user.id]
    )).rows[0];
    await pool.query(
      'UPDATE documents SET current_version_id=$1, updated_at=now() WHERE id=$2',
      [row.id, req.params.id]
    );
    await audit(req.user.id, 'version.upload', 'document_version', row.id, { revision });
    await searchUpsertById(req.params.id);
    ok(res, row);
  } catch (e) {
    if (e.code === '23505') {
      await storage.deleteObject(file_key).catch(() => {});
      return err(res, 409, 40901, 'Revision already exists for this document');
    }
    throw e;
  }
}));

// Download — issue a presigned GET URL; the browser fetches directly from storage.
app.get('/api/v1/versions/:vid/download-url', authMiddleware, r(async (req, res) => {
  const v = (await pool.query(
    'SELECT * FROM document_versions WHERE id=$1', [req.params.vid]
  )).rows[0];
  if (!v) return err(res, 404, 40401, 'Not found');

  const url = await storage.presignedGet({
    fileKey: v.file_key,
    downloadFileName: v.file_name,
  });
  await audit(req.user.id, 'version.download', 'document_version', v.id);
  ok(res, { download_url: url, expires_in: 300 });
}));

// ============================================================================
// Workflow
// ============================================================================
app.get('/api/v1/workflow-templates', authMiddleware, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT t.*, COALESCE(json_agg(s.* ORDER BY s.sequence) FILTER (WHERE s.sequence IS NOT NULL), '[]'::json) AS steps
     FROM workflow_templates t
     LEFT JOIN workflow_template_steps s ON s.template_code=t.template_code
     WHERE t.is_active=true
     GROUP BY t.template_code
     ORDER BY t.template_code`
  )).rows;
  ok(res, rows);
}));

app.post('/api/v1/versions/:vid/start-workflow', authMiddleware, r(async (req, res) => {
  const { template_code } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const inst = await wf.instantiate(client, {
      versionId: req.params.vid, explicit: template_code,
    });
    await client.query('COMMIT');
    await audit(req.user.id, 'workflow.start', 'workflow_instance', inst.id,
                { template: inst.template_code });

    // The version's current_status just changed (draft → in_review) → reindex
    const docId = (await pool.query(
      'SELECT document_id FROM document_versions WHERE id=$1', [req.params.vid]
    )).rows[0]?.document_id;
    if (docId) await searchUpsertById(docId);

    ok(res, inst);
  } catch (e) {
    await client.query('ROLLBACK');
    return err(res, 400, 40001, e.message);
  } finally { client.release(); }
}));

app.post('/api/v1/workflow-steps/:id/complete', authMiddleware, r(async (req, res) => {
  const { action, comment } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await wf.completeStep(client, {
      stepId: req.params.id, action, comment, userId: req.user.id,
    });
    await client.query('COMMIT');
    await audit(req.user.id, 'workflow.complete_step', 'workflow_step',
                req.params.id, { action, ...out });

    // The version's status may have changed → reindex
    if (out.version_id) {
      const docId = (await pool.query(
        'SELECT document_id FROM document_versions WHERE id=$1', [out.version_id]
      )).rows[0]?.document_id;
      if (docId) await searchUpsertById(docId);
    }

    ok(res, out);
  } catch (e) {
    await client.query('ROLLBACK');
    return err(res, 400, 40001, e.message);
  } finally { client.release(); }
}));

app.get('/api/v1/workflow/my-pending', authMiddleware, r(async (req, res) => {
  ok(res, await wf.getMyPendingSteps(pool, req.user.id));
}));

app.get('/api/v1/versions/:vid/workflow', authMiddleware, r(async (req, res) => {
  const inst = await wf.getInstanceForVersion(pool, req.params.vid);
  if (!inst) return err(res, 404, 40401, 'No workflow for this version');
  ok(res, inst);
}));

// ============================================================================
// Transmittals
// ============================================================================
app.get('/api/v1/projects/:pid/transmittals', authMiddleware, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT t.*, u.name AS sender_name,
       (SELECT COUNT(*) FROM transmittal_recipients tr WHERE tr.transmittal_id=t.id)::int
         AS recipient_count,
       (SELECT COUNT(*) FROM transmittal_recipients tr
          WHERE tr.transmittal_id=t.id AND tr.acknowledged_at IS NOT NULL)::int
         AS acknowledged_count
     FROM transmittals t JOIN users u ON u.id=t.sender_id
     WHERE t.project_id=$1 ORDER BY t.created_at DESC`,
    [req.params.pid]
  )).rows;
  ok(res, rows);
}));

app.post('/api/v1/projects/:pid/transmittals', authMiddleware, r(async (req, res) => {
  const { purpose, cover_note, version_ids, recipient_user_ids, due_at } = req.body || {};
  if (!purpose || !Array.isArray(version_ids) || !version_ids.length
      || !Array.isArray(recipient_user_ids) || !recipient_user_ids.length) {
    return err(res, 400, 40001,
      'purpose, version_ids[], recipient_user_ids[] required');
  }
  const proj = (await pool.query('SELECT code FROM projects WHERE id=$1', [req.params.pid])).rows[0];
  if (!proj) return err(res, 404, 40401, 'Project not found');
  const seq = (await pool.query(
    'SELECT COUNT(*)::int + 1 AS n FROM transmittals WHERE project_id=$1',
    [req.params.pid]
  )).rows[0].n;
  const trmNo = `${proj.code}-TRM-${new Date().getFullYear()}-${String(seq).padStart(4, '0')}`;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const t = (await client.query(
      `INSERT INTO transmittals
        (project_id, transmittal_no, purpose, cover_note, sender_id, status, sent_at, due_at)
       VALUES ($1,$2,$3,$4,$5,'sent',now(),$6) RETURNING *`,
      [req.params.pid, trmNo, purpose, cover_note || null, req.user.id, due_at || null]
    )).rows[0];
    for (let i = 0; i < version_ids.length; i++) {
      await client.query(
        `INSERT INTO transmittal_items (transmittal_id, document_version_id, position)
         VALUES ($1,$2,$3)`,
        [t.id, version_ids[i], i]
      );
    }
    for (const uid of recipient_user_ids) {
      await client.query(
        `INSERT INTO transmittal_recipients (transmittal_id, user_id) VALUES ($1,$2)`,
        [t.id, uid]
      );
    }

    // For each version included in this transmittal: if it was 'approved' and
    // this is its first transmittal, move it to 'issued'. Mirrors the MVP rule
    // that "approved + sent transmittal = issued".
    for (const vid of version_ids) {
      await client.query(
        `UPDATE document_versions
         SET status='issued', issued_at=COALESCE(issued_at, now())
         WHERE id=$1 AND status='approved'`,
        [vid]
      );
    }

    await client.query('COMMIT');
    await audit(req.user.id, 'transmittal.send', 'transmittal', t.id,
                { no: trmNo, recipients: recipient_user_ids.length });

    // Reindex affected documents
    const docs = (await pool.query(
      `SELECT DISTINCT document_id FROM document_versions WHERE id = ANY($1::uuid[])`,
      [version_ids]
    )).rows;
    for (const d of docs) await searchUpsertById(d.document_id);

    ok(res, t);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}));

app.get('/api/v1/transmittals/my-pending', authMiddleware, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT tr.id AS recipient_id, t.id AS transmittal_id, t.transmittal_no,
            t.purpose, t.sent_at, t.due_at, t.cover_note,
            u.name AS sender_name
     FROM transmittal_recipients tr
     JOIN transmittals t ON t.id=tr.transmittal_id
     JOIN users u ON u.id=t.sender_id
     WHERE tr.user_id=$1 AND tr.acknowledged_at IS NULL
     ORDER BY t.sent_at DESC`,
    [req.user.id]
  )).rows;
  ok(res, rows);
}));

app.get('/api/v1/transmittals/:id', authMiddleware, r(async (req, res) => {
  const t = (await pool.query('SELECT * FROM transmittals WHERE id=$1', [req.params.id])).rows[0];
  if (!t) return err(res, 404, 40401, 'Not found');
  const items = (await pool.query(
    `SELECT ti.*, dv.revision, dv.file_name, dv.status,
            d.doc_code, d.title
     FROM transmittal_items ti
     JOIN document_versions dv ON dv.id=ti.document_version_id
     JOIN documents d ON d.id=dv.document_id
     WHERE ti.transmittal_id=$1 ORDER BY ti.position`,
    [req.params.id]
  )).rows;
  const recipients = (await pool.query(
    `SELECT tr.*, u.name, u.email FROM transmittal_recipients tr
     JOIN users u ON u.id=tr.user_id
     WHERE tr.transmittal_id=$1`,
    [req.params.id]
  )).rows;
  ok(res, { ...t, items, recipients });
}));

app.post('/api/v1/transmittals/:id/recipients/:rid/acknowledge', authMiddleware, r(async (req, res) => {
  const { response } = req.body || {};
  const row = (await pool.query(
    `UPDATE transmittal_recipients
     SET acknowledged_at=now(), response=$1
     WHERE id=$2 AND user_id=$3 AND transmittal_id=$4 AND acknowledged_at IS NULL
     RETURNING *`,
    [response || null, req.params.rid, req.user.id, req.params.id]
  )).rows[0];
  if (!row) return err(res, 404, 40401, 'Recipient not found or already acknowledged');
  await audit(req.user.id, 'transmittal.acknowledge', 'transmittal',
              req.params.id, { recipient_id: req.params.rid });
  ok(res, row);
}));

// ============================================================================
// Health
// ============================================================================
app.get('/health', async (req, res) => {
  const checks = { api: 'ok' };
  try { await pool.query('SELECT 1'); checks.postgres = 'ok'; }
  catch { checks.postgres = 'fail'; }
  try { await search.es.ping(); checks.elasticsearch = 'ok'; }
  catch { checks.elasticsearch = 'fail'; }
  const allOk = Object.values(checks).every((v) => v === 'ok');
  res.status(allOk ? 200 : 503).json(checks);
});

// ============================================================================
// Boot
// ============================================================================
const PORT = Number(process.env.PORT) || 4000;

(async () => {
  await sso.init().catch((e) => console.error('SSO init failed:', e.message));
  await search.ensureIndex().catch((e) => console.error('search init failed:', e.message));

  app.listen(PORT, () => {
    console.log(`DCMS v1 API listening on http://localhost:${PORT}`);
    console.log(`Frontend expected at: ${FRONTEND_URL}`);
    console.log(`Password login: ${ALLOW_PASSWORD_LOGIN ? 'enabled' : 'disabled'}`);
    console.log(`SSO: ${sso.isEnabled() ? 'enabled' : 'disabled'}`);
  });
})();
