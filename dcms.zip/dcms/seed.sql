-- DCMS v1 — seed data
-- Demo users still have a bcrypt password ("password") so the bcrypt login keeps
-- working in dev with ALLOW_PASSWORD_LOGIN=true. In production they would arrive
-- via SSO and password_hash would be NULL.

WITH new_users AS (
  INSERT INTO users (email, name, password_hash, default_role) VALUES
    ('alice@example.com', 'Alice Chen',  crypt('password', gen_salt('bf', 10)), 'controller'),
    ('bob@example.com',   'Bob Smith',   crypt('password', gen_salt('bf', 10)), 'reviewer'),
    ('chris@example.com', 'Chris Liang', crypt('password', gen_salt('bf', 10)), 'member')
  RETURNING id, email
), new_project AS (
  INSERT INTO projects (code, name) VALUES ('BR26', 'Bridge-PJ-2026')
  RETURNING id
), members AS (
  INSERT INTO project_members (project_id, user_id, role, discipline)
  SELECT (SELECT id FROM new_project), id,
         CASE email
           WHEN 'alice@example.com' THEN 'controller'
           WHEN 'bob@example.com'   THEN 'reviewer'
           ELSE 'member' END,
         CASE email
           WHEN 'bob@example.com'   THEN 'STR'
           WHEN 'chris@example.com' THEN 'ARC'
           ELSE NULL END
  FROM new_users
  RETURNING user_id
)
SELECT 'seeded users + project' AS status;

-- ============================================================================
-- Workflow templates
-- ============================================================================
INSERT INTO workflow_templates (template_code, name, description, applies_to, final_status_on_complete) VALUES
  ('standard_review',
   'Standard design review',
   '4-step review for design deliverables.',
   '{"source":"design"}'::jsonb,
   'approved'),
  ('fast_track',
   'Fast track (for information)',
   'Single controller log step. For MoMs, letters, status reports.',
   '{"doc_type":["MOM","LET","RPT"]}'::jsonb,
   'issued'),
  ('vendor_submittal',
   'Vendor submittal',
   '3-step review for incoming vendor data.',
   '{"source":"vendor"}'::jsonb,
   'approved');

INSERT INTO workflow_template_steps
  (template_code, sequence, step_name, assignee_role, sla_days, on_reject) VALUES
  ('standard_review', 1, 'IDC',              'discipline_lead',     3, 'restart'),
  ('standard_review', 2, 'Internal review',  'discipline_lead',     2, 'restart'),
  ('standard_review', 3, 'Client review',    'client_rep',          5, 'restart'),
  ('standard_review', 4, 'Project approval', 'project_manager',     1, 'restart'),
  ('fast_track',      1, 'Controller log',   'document_controller', 1, 'restart'),
  ('vendor_submittal',1, 'DC log',            'document_controller', 1, 'restart'),
  ('vendor_submittal',2, 'Discipline review', 'discipline_lead',     5, 'restart'),
  ('vendor_submittal',3, 'Disposition',       'discipline_lead',     1, 'restart');

-- ============================================================================
-- Sample documents + a sent transmittal + project role assignments
-- ============================================================================
DO $$
DECLARE
  v_project uuid;
  v_alice   uuid;
  v_bob     uuid;
  v_chris   uuid;
  v_doc1    uuid;
  v_doc2    uuid;
  v_ver1    uuid;
  v_ver2    uuid;
  v_trm     uuid;
BEGIN
  SELECT id INTO v_project FROM projects WHERE code='BR26';
  SELECT id INTO v_alice   FROM users WHERE email='alice@example.com';
  SELECT id INTO v_bob     FROM users WHERE email='bob@example.com';
  SELECT id INTO v_chris   FROM users WHERE email='chris@example.com';

  -- Role assignments: Alice wears the controller/PM/client hats for demo simplicity
  INSERT INTO project_role_assignments (project_id, role_in_workflow, discipline, user_id) VALUES
    (v_project, 'document_controller', NULL,  v_alice),
    (v_project, 'project_manager',     NULL,  v_alice),
    (v_project, 'client_rep',          NULL,  v_alice),
    (v_project, 'discipline_lead',     'STR', v_bob),
    (v_project, 'discipline_lead',     'ARC', v_chris);

  INSERT INTO documents (project_id, doc_code, title, discipline, doc_type, created_by)
    VALUES (v_project, 'BR26-ARC-DWG-001', 'Architectural floor plan, level 1', 'ARC', 'DWG', v_chris)
    RETURNING id INTO v_doc1;

  INSERT INTO documents (project_id, doc_code, title, discipline, doc_type, created_by)
    VALUES (v_project, 'BR26-STR-CAL-001', 'Beam load calculation, span 12m', 'STR', 'CAL', v_alice)
    RETURNING id INTO v_doc2;

  -- file_key uses the v1 layout (documents/{document_id}/...) — these are seed placeholders;
  -- in real use the file lives in MinIO under that key. For dev, downloads of these will
  -- return a presigned URL that 404s — replace by uploading a real version through the UI.
  INSERT INTO document_versions
    (document_id, revision, status, file_key, file_name, file_size, mime_type,
     checksum_sha256, change_note, created_by, issued_at)
    VALUES (v_doc1, 'A', 'issued',
            'documents/' || v_doc1 || '/seed-floor-plan-L1.pdf', 'floor-plan-L1.pdf',
            102400, 'application/pdf',
            'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',
            'Initial release', v_chris, now())
    RETURNING id INTO v_ver1;
  UPDATE documents SET current_version_id = v_ver1 WHERE id = v_doc1;

  INSERT INTO document_versions
    (document_id, revision, status, file_key, file_name, file_size, mime_type,
     checksum_sha256, change_note, created_by)
    VALUES (v_doc2, 'A', 'draft',
            'documents/' || v_doc2 || '/seed-beam-calc-A.pdf', 'beam-calc-A.pdf',
            55200, 'application/pdf',
            'b665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3',
            'For peer review', v_alice, NULL)
    RETURNING id INTO v_ver2;
  UPDATE documents SET current_version_id = v_ver2 WHERE id = v_doc2;

  -- One sent transmittal: Alice → Chris with the issued floor plan
  INSERT INTO transmittals (project_id, transmittal_no, purpose, cover_note, sender_id, status, sent_at)
    VALUES (v_project, 'BR26-TRM-2026-0001', 'for_construction',
            'Please confirm receipt before Friday.', v_alice, 'sent', now())
    RETURNING id INTO v_trm;

  INSERT INTO transmittal_items (transmittal_id, document_version_id) VALUES (v_trm, v_ver1);
  INSERT INTO transmittal_recipients (transmittal_id, user_id) VALUES (v_trm, v_chris);

  INSERT INTO audit_logs (user_id, action, entity_type, entity_id, detail)
    VALUES (v_alice, 'transmittal.send', 'transmittal', v_trm,
            jsonb_build_object('no', 'BR26-TRM-2026-0001'));
END $$;
