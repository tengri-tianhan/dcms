// DCMS v1 — storage layer (S3 / MinIO)
// All file traffic goes browser ↔ object store directly; the API only handles metadata.

const {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
  DeleteObjectCommand,
} = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const crypto = require('crypto');
const path = require('path');

const BUCKET = process.env.S3_BUCKET || 'dcms-files';
const PUBLIC_ENDPOINT = process.env.S3_PUBLIC_ENDPOINT || process.env.S3_ENDPOINT;

// Internal client — used for server-side operations (HEAD, DELETE, integrity check)
const s3 = new S3Client({
  endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

// Public client — used to sign URLs the browser will hit. Signature is bound to host.
const s3Public = new S3Client({
  endpoint: PUBLIC_ENDPOINT,
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

function buildFileKey(documentId, originalName) {
  const ext = path.extname(originalName || '').toLowerCase();
  const safeName = path.basename(originalName || '', ext)
    .replace(/[^a-z0-9_-]/gi, '_')
    .slice(0, 40);
  return `documents/${documentId}/${crypto.randomUUID()}-${safeName}${ext}`;
}

async function presignedPut({ fileKey, mimeType, expiresIn = 600 }) {
  const cmd = new PutObjectCommand({
    Bucket: BUCKET,
    Key: fileKey,
    ContentType: mimeType,
  });
  return getSignedUrl(s3Public, cmd, { expiresIn });
}

async function presignedGet({ fileKey, downloadFileName, expiresIn = 300 }) {
  const cmd = new GetObjectCommand({
    Bucket: BUCKET,
    Key: fileKey,
    ResponseContentDisposition:
      `attachment; filename*=UTF-8''${encodeURIComponent(downloadFileName)}`,
  });
  return getSignedUrl(s3Public, cmd, { expiresIn });
}

async function objectExists(fileKey) {
  try {
    await s3.send(new HeadObjectCommand({ Bucket: BUCKET, Key: fileKey }));
    return true;
  } catch (e) {
    if (e.name === 'NotFound' || e.$metadata?.httpStatusCode === 404) return false;
    throw e;
  }
}

async function getObjectHead(fileKey) {
  const r = await s3.send(new HeadObjectCommand({ Bucket: BUCKET, Key: fileKey }));
  return { size: r.ContentLength, mimeType: r.ContentType, etag: r.ETag };
}

async function deleteObject(fileKey) {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: fileKey }));
}

// Server-side integrity check — streams the object and hashes. Expensive; use sparingly.
async function computeRemoteChecksum(fileKey) {
  const r = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: fileKey }));
  const hash = crypto.createHash('sha256');
  for await (const chunk of r.Body) hash.update(chunk);
  return hash.digest('hex');
}

module.exports = {
  s3, BUCKET,
  buildFileKey,
  presignedPut,
  presignedGet,
  objectExists,
  getObjectHead,
  deleteObject,
  computeRemoteChecksum,
};
