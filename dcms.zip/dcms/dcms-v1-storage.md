# DCMS v1 — MinIO / S3 Integration

I'm replacing the local disk storage from the MVP with S3-compatible object storage. In dev I run MinIO locally; in production I point the same code at AWS S3, Alibaba OSS, Tencent COS, or Cloudflare R2 — whichever the host environment provides. This is the step I take before going to production.

## 1. Why I'm doing this

The MVP uses `multer` to write uploads straight to local disk on the API server. That works for demos, but it breaks in three ways once I leave the laptop:

- **I can't scale horizontally.** The moment I add a second API instance, files exist on one host and not the other, and downloads fail half the time.
- **The API process carries the file traffic.** A 100 MB drawing uploaded through Node consumes a request buffer and a socket for the duration; once a project ramps up, file traffic starves the metadata API.
- **I lose lifecycle, encryption, versioning, audit, and replication for free.** Object storage gives me all of these as configuration; on local disk I'd have to build each one.

After this change, the API only handles metadata (a few KB of JSON per request). The file bytes travel directly between the client and the object store, authorized by presigned URLs that the API issues on demand.

## 2. Architecture

```
  Client ── POST /init-upload ─▶ Node API
  Client ◀── { upload_url, file_key } ── Node API   (metadata only)
  Client ── PUT upload_url (file body) ─▶ MinIO     (direct, heavy traffic)
  Client ── POST /versions { file_key, checksum, ... } ─▶ Node API   (confirm)
```

Downloads work the same way in reverse: the API hands back a short-lived signed GET URL and the client fetches the bytes directly from MinIO. The API never touches the stream.

## 3. Change list

| File | Change |
|---|---|
| `docker-compose.yml` | Add MinIO service |
| `backend/package.json` | Add `@aws-sdk/client-s3` and `@aws-sdk/s3-request-presigner`; remove `multer` |
| `backend/lib/storage.js` | **New** — S3 client + presign helpers |
| `backend/init-bucket.js` | **New** — create the bucket on first run |
| `backend/server.js` | Rewire upload and download endpoints |
| `backend/.env.example` | Add S3 configuration |
| `frontend/src/App.jsx` | Two-phase upload component; presigned-URL download |
| `backend/migrate-files.js` | **New** — one-shot migration from local disk to MinIO for existing MVP files |

## 4. docker-compose.yml

I add a MinIO service:

```yaml
services:
  postgres:
    # ... unchanged

  minio:
    image: minio/minio:latest
    command: server /data --console-address ":9001"
    environment:
      MINIO_ROOT_USER: minioadmin
      MINIO_ROOT_PASSWORD: minioadmin
    ports:
      - "9000:9000"   # S3 API
      - "9001:9001"   # Web console (http://localhost:9001)
    volumes:
      - miniodata:/data
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 5s
      timeout: 3s
      retries: 10

volumes:
  pgdata:
  miniodata:
```

After it's up I can sign into the MinIO console at `http://localhost:9001` with `minioadmin / minioadmin`. I rotate those credentials before anything goes to production.

## 5. backend/.env.example

I add:

```bash
# existing
DB_HOST=localhost
DB_PORT=5432
DB_USER=dcms
DB_PASSWORD=dcms_pw
DB_NAME=dcms
JWT_SECRET=dev-secret-change-me
PORT=4000

# new — S3
S3_ENDPOINT=http://localhost:9000
S3_REGION=us-east-1
S3_BUCKET=dcms-files
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin
S3_FORCE_PATH_STYLE=true               # MinIO requires true; AWS S3 set to false
S3_PUBLIC_ENDPOINT=http://localhost:9000   # what the browser sees (differs from internal endpoint in prod)
```

The last variable matters. When my Node process talks to MinIO inside the Docker network it uses `http://minio:9000`, but the **presigned URL I hand to the browser** must point at an address the browser can actually reach (`http://localhost:9000` in dev, `https://files.example.com` in prod). Presigned URLs bind the signature to the host, so I have to compute the signature against the correct host for each side.

## 6. backend/lib/storage.js (new)

```js
const {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  HeadObjectCommand,
  DeleteObjectCommand,
} = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const crypto = require('crypto');
const path = require('path');

const BUCKET = process.env.S3_BUCKET || 'dcms-files';
const PUBLIC_ENDPOINT = process.env.S3_PUBLIC_ENDPOINT || process.env.S3_ENDPOINT;

// Server-side client (internal endpoint)
const s3 = new S3Client({
  endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

// Client used to sign URLs for the browser (public endpoint)
const s3Public = new S3Client({
  endpoint: PUBLIC_ENDPOINT,
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

function buildFileKey(documentId, originalName) {
  const ext = path.extname(originalName || '').toLowerCase();
  const safeName = path.basename(originalName, ext)
    .replace(/[^a-z0-9_-]/gi, '_')
    .slice(0, 40);
  return `documents/${documentId}/${crypto.randomUUID()}-${safeName}${ext}`;
}

async function presignedPut({ fileKey, mimeType, expiresIn = 600 }) {
  const cmd = new PutObjectCommand({
    Bucket: BUCKET,
    Key: fileKey,
    ContentType: mimeType,
  });
  return getSignedUrl(s3Public, cmd, { expiresIn });
}

async function presignedGet({ fileKey, downloadFileName, expiresIn = 300 }) {
  const cmd = new GetObjectCommand({
    Bucket: BUCKET,
    Key: fileKey,
    ResponseContentDisposition:
      `attachment; filename*=UTF-8''${encodeURIComponent(downloadFileName)}`,
  });
  return getSignedUrl(s3Public, cmd, { expiresIn });
}

async function objectExists(fileKey) {
  try {
    await s3.send(new HeadObjectCommand({ Bucket: BUCKET, Key: fileKey }));
    return true;
  } catch (e) {
    if (e.name === 'NotFound' || e.$metadata?.httpStatusCode === 404) return false;
    throw e;
  }
}

async function getObjectHead(fileKey) {
  const r = await s3.send(new HeadObjectCommand({ Bucket: BUCKET, Key: fileKey }));
  return { size: r.ContentLength, mimeType: r.ContentType, etag: r.ETag };
}

async function deleteObject(fileKey) {
  await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: fileKey }));
}

// Server-side integrity check — streams the object and hashes
async function computeRemoteChecksum(fileKey) {
  const r = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: fileKey }));
  const hash = crypto.createHash('sha256');
  for await (const chunk of r.Body) hash.update(chunk);
  return hash.digest('hex');
}

module.exports = {
  s3, BUCKET,
  buildFileKey,
  presignedPut,
  presignedGet,
  objectExists,
  getObjectHead,
  deleteObject,
  computeRemoteChecksum,
};
```

A few things worth flagging in this file:

- I keep two clients (`s3` and `s3Public`) because internal and external endpoints differ. Signatures bind to host, so I have to pick the right client for each operation.
- `buildFileKey` shards by document ID and adds a UUID so I never get collisions and can't be path-traversed by a malicious filename.
- `computeRemoteChecksum` lets me verify what the client uploaded by streaming the object back through Node and hashing it. It's expensive (the bytes pass through Node after all), so I only call it when integrity actually matters, and in production I'd move it to an async job.

## 7. backend/init-bucket.js (new)

```js
const { S3Client, HeadBucketCommand, CreateBucketCommand } = require('@aws-sdk/client-s3');

const BUCKET = process.env.S3_BUCKET || 'dcms-files';
const client = new S3Client({
  endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

(async () => {
  try {
    await client.send(new HeadBucketCommand({ Bucket: BUCKET }));
    console.log(`Bucket "${BUCKET}" already exists`);
  } catch (e) {
    if (e.$metadata?.httpStatusCode === 404 || e.name === 'NotFound') {
      await client.send(new CreateBucketCommand({ Bucket: BUCKET }));
      console.log(`Created bucket "${BUCKET}"`);
    } else {
      console.error('init-bucket failed:', e.message);
      process.exit(1);
    }
  }
})();
```

I wire it into `package.json`:

```json
"scripts": {
  "start": "node server.js",
  "dev": "node --watch server.js",
  "init-bucket": "node init-bucket.js"
}
```

My deploy sequence is `npm run init-bucket` once, then `npm start`.

## 8. backend/server.js changes

I remove multer, then add the two new endpoints and rewrite the download to return a presigned URL.

**Remove:**

```js
const multer = require('multer');
const fs = require('fs');
const path = require('path');
// ...
const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const upload = multer({ dest: UPLOAD_DIR, limits: { fileSize: 100 * 1024 * 1024 } });
```

**Add:**

```js
const storage = require('./lib/storage');
```

**Replace the old `POST /api/v1/documents/:id/versions`** with the two-phase flow:

```js
// Step 1: request an upload URL
app.post('/api/v1/documents/:id/versions/init-upload', auth, r(async (req, res) => {
  const { file_name, mime_type, file_size } = req.body || {};
  if (!file_name || !mime_type || !file_size) {
    return err(res, 400, 40001, 'file_name, mime_type, file_size required');
  }
  if (file_size > 200 * 1024 * 1024) {
    return err(res, 400, 40001, 'File too large (200 MB max)');
  }
  // Confirm the document exists before signing — fail fast for the client
  const d = (await pool.query(
    'SELECT id FROM documents WHERE id=$1 AND deleted_at IS NULL',
    [req.params.id]
  )).rows[0];
  if (!d) return err(res, 404, 40401, 'Document not found');

  const fileKey = storage.buildFileKey(req.params.id, file_name);
  const uploadUrl = await storage.presignedPut({ fileKey, mimeType: mime_type });

  ok(res, { file_key: fileKey, upload_url: uploadUrl, expires_in: 600 });
}));

// Step 2: confirm the upload finished and register the version
app.post('/api/v1/documents/:id/versions', auth, r(async (req, res) => {
  const { revision, file_key, file_name, file_size, mime_type,
          checksum_sha256, change_note } = req.body || {};
  if (!revision || !file_key || !file_name || !file_size
      || !mime_type || !checksum_sha256 || !change_note) {
    return err(res, 400, 40001,
      'revision, file_key, file_name, file_size, mime_type, ' +
      'checksum_sha256, change_note required');
  }

  // Server-side check: the object exists and the size matches
  const head = await storage.getObjectHead(file_key).catch(() => null);
  if (!head) return err(res, 400, 40001, 'Upload not found on storage');
  if (head.size !== Number(file_size)) {
    return err(res, 400, 40001, 'File size mismatch');
  }

  // Optional: server-side SHA recompute. Heavy — I'd move this to an async job in prod.
  // const remoteSha = await storage.computeRemoteChecksum(file_key);
  // if (remoteSha !== checksum_sha256) {
  //   await storage.deleteObject(file_key);
  //   return err(res, 400, 40001, 'Checksum mismatch');
  // }

  try {
    const row = (await pool.query(
      `INSERT INTO document_versions
        (document_id, revision, status, file_key, file_name, file_size,
         mime_type, checksum_sha256, change_note, created_by)
       VALUES ($1,$2,'draft',$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [req.params.id, revision, file_key, file_name, file_size,
       mime_type, checksum_sha256, change_note, req.user.id]
    )).rows[0];
    await pool.query(
      'UPDATE documents SET current_version_id=$1, updated_at=now() WHERE id=$2',
      [row.id, req.params.id]
    );
    await audit(req.user.id, 'version.upload', 'document_version', row.id, { revision });
    ok(res, row);
  } catch (e) {
    if (e.code === '23505') {
      await storage.deleteObject(file_key);   // clean up the orphan
      return err(res, 409, 40901, 'Revision already exists');
    }
    throw e;
  }
}));
```

**Replace the old `GET /api/v1/versions/:vid/download`** with a presigned URL endpoint:

```js
app.get('/api/v1/versions/:vid/download-url', auth, r(async (req, res) => {
  const v = (await pool.query(
    'SELECT * FROM document_versions WHERE id=$1', [req.params.vid]
  )).rows[0];
  if (!v) return err(res, 404, 40401, 'Not found');

  const url = await storage.presignedGet({
    fileKey: v.file_key,
    downloadFileName: v.file_name,
  });
  await audit(req.user.id, 'version.download', 'document_version', v.id);
  ok(res, { download_url: url, expires_in: 300 });
}));
```

I drop the old streaming download endpoint entirely. If I needed a fallback I could keep it, but the API shouldn't be in the bytes-streaming business anymore.

## 9. frontend/src/App.jsx changes

I rewrite `UploadVersionModal` as a four-step flow: ask for a URL, upload, hash, register.

```jsx
function UploadVersionModal({ docId, onClose, onUploaded }) {
  const [file, setFile] = useState(null);
  const [revision, setRevision] = useState('A');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    if (!file) return setError('Pick a file');
    setBusy(true); setError(''); setProgress('');
    try {
      // 1) Request the upload URL
      setProgress('Requesting upload URL…');
      const init = await api.post(`/documents/${docId}/versions/init-upload`, {
        file_name: file.name,
        mime_type: file.type || 'application/octet-stream',
        file_size: file.size,
      });

      // 2) PUT the file straight to MinIO / S3
      setProgress('Uploading to storage…');
      const putRes = await fetch(init.upload_url, {
        method: 'PUT',
        body: file,
        headers: { 'Content-Type': file.type || 'application/octet-stream' },
      });
      if (!putRes.ok) throw new Error(`Upload failed: ${putRes.status}`);

      // 3) Compute SHA-256 in the browser
      setProgress('Computing checksum…');
      const buf = await file.arrayBuffer();
      const hashBuf = await crypto.subtle.digest('SHA-256', buf);
      const sha = Array.from(new Uint8Array(hashBuf))
        .map((b) => b.toString(16).padStart(2, '0')).join('');

      // 4) Register the version with metadata
      setProgress('Registering version…');
      const v = await api.post(`/documents/${docId}/versions`, {
        revision,
        file_key: init.file_key,
        file_name: file.name,
        file_size: file.size,
        mime_type: file.type || 'application/octet-stream',
        checksum_sha256: sha,
        change_note: note || 'Initial upload',
      });
      onUploaded(v);
    } catch (e) { setError(e.message); }
    finally { setBusy(false); setProgress(''); }
  };

  return (
    <div className="modal-bg" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h3>Upload new version</h3>
        <label>Revision
          <input value={revision} onChange={(e) => setRevision(e.target.value)} maxLength={3} required />
        </label>
        <label>File
          <input type="file" onChange={(e) => setFile(e.target.files[0])} required />
        </label>
        <label>Change note
          <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="What changed?" />
        </label>
        {progress && <div className="muted small">{progress}</div>}
        {error && <div className="error">{error}</div>}
        <div className="actions">
          <button type="button" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-pri" disabled={busy}>
            {busy ? 'Uploading…' : 'Upload'}
          </button>
        </div>
      </form>
    </div>
  );
}
```

I rewire download to jump to the presigned URL:

```jsx
const download = async (vid) => {
  try {
    const { download_url } = await api.get(`/versions/${vid}/download-url`);
    window.location.href = download_url;
  } catch (e) { setError(e.message); }
};
```

The browser computes SHA-256 synchronously here, which blocks the UI for a second or two on large files. I'll move that into a Web Worker in a later iteration; the MVP-grade flow is fine for now.

## 10. backend/package.json

```json
{
  "dependencies": {
    "@aws-sdk/client-s3": "^3.620.0",
    "@aws-sdk/s3-request-presigner": "^3.620.0",
    "bcryptjs": "^2.4.3",
    "cors": "^2.8.5",
    "express": "^4.19.2",
    "jsonwebtoken": "^9.0.2",
    "pg": "^8.11.5"
  }
}
```

`multer` is gone.

## 11. Migrating MVP files (backend/migrate-files.js)

For the files that landed on local disk during the MVP, I write a one-shot migration that copies each one into MinIO and updates `document_versions.file_key`:

```js
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Pool } = require('pg');
const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';
const BUCKET = process.env.S3_BUCKET || 'dcms-files';

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT) || 5432,
  user: process.env.DB_USER || 'dcms',
  password: process.env.DB_PASSWORD || 'dcms_pw',
  database: process.env.DB_NAME || 'dcms',
});

const s3 = new S3Client({
  endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
  region: process.env.S3_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_KEY || 'minioadmin',
  },
  forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
});

(async () => {
  const versions = (await pool.query(
    `SELECT id, document_id, file_key, file_name, mime_type FROM document_versions`
  )).rows;

  let moved = 0, skipped = 0, failed = 0;
  for (const v of versions) {
    // Skip anything already in the new key format
    if (v.file_key.startsWith('documents/')) { skipped++; continue; }
    const localPath = path.join(UPLOAD_DIR, v.file_key);
    if (!fs.existsSync(localPath)) {
      console.warn(`MISSING ${v.id}: ${localPath}`);
      failed++; continue;
    }
    const body = fs.readFileSync(localPath);
    const ext = path.extname(v.file_name || '').toLowerCase();
    const newKey = `documents/${v.document_id}/${crypto.randomUUID()}${ext}`;
    await s3.send(new PutObjectCommand({
      Bucket: BUCKET, Key: newKey, Body: body, ContentType: v.mime_type,
    }));
    await pool.query(
      'UPDATE document_versions SET file_key=$1 WHERE id=$2',
      [newKey, v.id]
    );
    moved++;
    console.log(`OK  ${v.id}: ${v.file_key} → ${newKey}`);
  }
  console.log(`\nDone. moved=${moved} skipped=${skipped} failed=${failed}`);
  await pool.end();
})().catch((e) => { console.error(e); process.exit(1); });
```

I run it once:

```bash
cd backend
node migrate-files.js
```

After the report says zero failures I delete `./uploads/`.

## 12. How I verify it works

```bash
# 1) Restart with MinIO added
docker compose up -d
cd backend && npm install && npm run init-bucket && npm run dev

# 2) Sign in as Alice, upload a new version
# 3) Check the MinIO console at http://localhost:9001
#    — there should be an object under documents/{id}/...
# 4) Click Download in the UI — the browser navigates to a signed
#    http://localhost:9000/dcms-files/... URL and the file downloads
```

## 13. Cutting over to a real S3 in production

Only environment variables change; the code is unchanged.

```bash
S3_ENDPOINT=https://s3.ap-northeast-1.amazonaws.com
S3_PUBLIC_ENDPOINT=https://s3.ap-northeast-1.amazonaws.com
S3_REGION=ap-northeast-1
S3_BUCKET=dcms-files-prod
S3_ACCESS_KEY=AKIA...
S3_SECRET_KEY=...
S3_FORCE_PATH_STYLE=false        # AWS S3 doesn't use path style
```

The same env-only swap works for Alibaba OSS, Tencent COS, Cloudflare R2, anything S3-compatible.

## 14. What I'm leaving for later

- **Virus scanning.** Once the object lands in S3 I trigger a worker that runs ClamAV; on a hit I delete the object and notify the uploader.
- **Lifecycle policies.** Objects on superseded versions get moved to a cold tier (Glacier / OSS-Archive) after N years.
- **CORS.** In production the bucket needs CORS rules that allow PUT/GET from the frontend's domain only.
- **Server-side encryption.** I add `ServerSideEncryption: 'AES256'` to `PutObjectCommand`.
- **Multipart upload.** For large files I switch to the SDK's `Upload` class and show a real progress bar in the UI.
