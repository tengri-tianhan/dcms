# DCMS v1 — Workflow Engine

Once a version is submitted, the engine instantiates a workflow from a template, assigns each step to a specific person based on role and discipline, and only that person can sign off. After they do, the engine advances to the next step, and so on until the workflow ends and the version reaches its final status.

## 1. Why

The MVP state machine has two problems I can't ship:

- **Anyone can sign.** `POST /transitions { to_status: 'approved' }` doesn't check whether the caller is actually the approver. Fine for demos, dangerous in real projects where a reviewer could bypass the approver and push something through.
- **The process is implicit.** The `draft → review → approval → issued` path is hard-coded in the frontend's buttons. A project that wants double review or an extra client step would need a code change.

The workflow engine moves both of these out of code and into data:

- **Who can do what** becomes `workflow_steps.assignee_id`, resolved at runtime.
- **What the process looks like** becomes `workflow_templates`, edited by an admin.

## 2. Design

### 2.1 Core concepts

- **Workflow template** — a configurable sequence of steps. I ship three (standard review, fast track, vendor submittal); admins can add more.
- **Workflow instance** — one per version. When a version is submitted, the engine instantiates a workflow by copying steps from a template and binding them to this specific version.
- **Workflow step** — a concrete task inside an instance, with an assignee, an SLA, and an action (approve / reject / comment).
- **Role assignment** — project-level mapping from abstract roles in templates (`discipline_lead@STR`) to concrete user IDs.

### 2.2 Lifecycle

```
1. Controller or author submits a version → POST /versions/:vid/start-workflow
   ↓
2. Engine picks a template, copies its steps into workflow_steps
   ↓
3. Engine resolves the first step's assignee, marks it active
   version.status: draft → in_review
   ↓
4. Assignee sees the task in their inbox → completes it
   ↓
5. Engine looks at the action:
     - approve  → resolve next step's assignee, advance current_step
     - reject   → instance ends, version goes back to draft
     - comment  → no advance, task stays active
   ↓
6. Last step approved → instance completed
   version.status set to the template's final status (approved or issued)
```

### 2.3 Role resolution (the part that matters)

Templates use abstract roles like `discipline_lead`. When a STR/DWG document runs the standard review, the engine has to figure out who the STR discipline lead actually is on this project. My rule is:

1. Try `(project, role, discipline)` — exact match wins.
2. Fall back to `(project, role, NULL)` — project-wide assignment.
3. If neither matches, suspend the step and notify the admin to assign someone. The task stays parked until that happens.

The assignment table allows multiple users per role (for rotation or quorum). The MVP picks the first one by `priority`; I'll generalize that later.

## 3. Schema changes

I append to `migrate.sql`:

```sql
-- Workflow templates
CREATE TABLE workflow_templates (
  template_code text PRIMARY KEY,
  name          text NOT NULL,
  description   text,
  applies_to    jsonb NOT NULL DEFAULT '{}'::jsonb,
  -- applies_to examples: {"source":"vendor"} or {"doc_type":["DWG","CAL"]}
  -- The engine uses this for default selection; a caller can override explicitly.
  final_status_on_complete text NOT NULL DEFAULT 'approved'
    CHECK (final_status_on_complete IN ('approved', 'issued')),
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE workflow_template_steps (
  template_code text NOT NULL REFERENCES workflow_templates(template_code) ON DELETE CASCADE,
  sequence      int NOT NULL,
  step_name     text NOT NULL,
  assignee_role text NOT NULL,
  -- 'discipline_lead' | 'project_manager' | 'client_rep' | 'document_controller' | ...
  sla_days      int,
  on_reject     text NOT NULL DEFAULT 'restart'
                CHECK (on_reject IN ('restart', 'previous_step', 'cancel')),
  PRIMARY KEY (template_code, sequence)
);

-- Project-level role assignment — abstract role to concrete user
CREATE TABLE project_role_assignments (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id       uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  role_in_workflow text NOT NULL,
  discipline       text,   -- NULL = applies to all disciplines
  user_id          uuid NOT NULL REFERENCES users(id),
  priority         int NOT NULL DEFAULT 0,    -- lower = picked first
  UNIQUE (project_id, role_in_workflow, discipline, user_id)
);

CREATE INDEX idx_role_assignments_lookup
  ON project_role_assignments(project_id, role_in_workflow, discipline, priority);

-- Extra columns on workflow_steps (not in the MVP table)
ALTER TABLE workflow_steps
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'active', 'completed', 'skipped')),
  ADD COLUMN IF NOT EXISTS completed_by uuid REFERENCES users(id);

-- Extra columns on workflow_instances
ALTER TABLE workflow_instances
  ADD COLUMN IF NOT EXISTS template_code text REFERENCES workflow_templates(template_code),
  ADD COLUMN IF NOT EXISTS current_step_sequence int;
```

## 4. Seed data — three templates and the role assignments

I append to `seed.sql`:

```sql
-- Template 1: Standard design review
INSERT INTO workflow_templates (template_code, name, applies_to, final_status_on_complete) VALUES
  ('standard_review', 'Standard design review',
   '{"source":"design"}'::jsonb, 'approved'),
  ('fast_track', 'Fast track (for information)',
   '{"doc_type":["MOM","LET","RPT"]}'::jsonb, 'issued'),
  ('vendor_submittal', 'Vendor submittal',
   '{"source":"vendor"}'::jsonb, 'approved');

INSERT INTO workflow_template_steps (template_code, sequence, step_name, assignee_role, sla_days, on_reject) VALUES
  ('standard_review', 1, 'IDC',              'discipline_lead',     3, 'restart'),
  ('standard_review', 2, 'Internal review',  'discipline_lead',     2, 'restart'),
  ('standard_review', 3, 'Client review',    'client_rep',          5, 'restart'),
  ('standard_review', 4, 'Project approval', 'project_manager',     1, 'restart');

INSERT INTO workflow_template_steps (template_code, sequence, step_name, assignee_role, sla_days, on_reject) VALUES
  ('fast_track', 1, 'Controller log', 'document_controller', 1, 'restart');

INSERT INTO workflow_template_steps (template_code, sequence, step_name, assignee_role, sla_days, on_reject) VALUES
  ('vendor_submittal', 1, 'DC log',            'document_controller', 1, 'restart'),
  ('vendor_submittal', 2, 'Discipline review', 'discipline_lead',     5, 'restart'),
  ('vendor_submittal', 3, 'Disposition',       'discipline_lead',     1, 'restart');

-- Role assignments for Bridge-PJ-2026.
-- Alice wears three hats here for demo simplicity.
DO $$
DECLARE
  v_proj  uuid;
  v_alice uuid;
  v_bob   uuid;
  v_chris uuid;
BEGIN
  SELECT id INTO v_proj  FROM projects WHERE code='BR26';
  SELECT id INTO v_alice FROM users    WHERE email='alice@example.com';
  SELECT id INTO v_bob   FROM users    WHERE email='bob@example.com';
  SELECT id INTO v_chris FROM users    WHERE email='chris@example.com';

  INSERT INTO project_role_assignments (project_id, role_in_workflow, discipline, user_id) VALUES
    (v_proj, 'document_controller', NULL, v_alice),
    (v_proj, 'project_manager',     NULL, v_alice),
    (v_proj, 'client_rep',          NULL, v_alice),
    (v_proj, 'discipline_lead',     'STR', v_bob),
    (v_proj, 'discipline_lead',     'ARC', v_chris);
END $$;
```

## 5. Engine code — backend/lib/workflow.js (new)

```js
const VERSION_TO_INREVIEW = "UPDATE document_versions SET status='in_review' WHERE id=$1";
const VERSION_TO_DRAFT    = "UPDATE document_versions SET status='draft' WHERE id=$1";
const VERSION_TO_FINAL    = "UPDATE document_versions SET status=$2, issued_at=CASE WHEN $2='issued' THEN now() ELSE issued_at END WHERE id=$1";

// Resolve an abstract role into a concrete user_id
async function resolveAssignee(client, { projectId, role, discipline }) {
  // 1) Exact (project, role, discipline) match
  let r = await client.query(
    `SELECT user_id FROM project_role_assignments
     WHERE project_id=$1 AND role_in_workflow=$2 AND discipline=$3
     ORDER BY priority LIMIT 1`,
    [projectId, role, discipline]
  );
  if (r.rows.length) return r.rows[0].user_id;
  // 2) Project-wide (discipline IS NULL) fallback
  r = await client.query(
    `SELECT user_id FROM project_role_assignments
     WHERE project_id=$1 AND role_in_workflow=$2 AND discipline IS NULL
     ORDER BY priority LIMIT 1`,
    [projectId, role]
  );
  return r.rows[0]?.user_id || null;
}

// Pick a template: explicit > applies_to match > standard_review fallback
async function pickTemplate(client, { source, doc_type, explicit }) {
  if (explicit) {
    const r = await client.query(
      'SELECT * FROM workflow_templates WHERE template_code=$1 AND is_active=true',
      [explicit]
    );
    if (r.rows.length) return r.rows[0];
  }
  const all = (await client.query(
    'SELECT * FROM workflow_templates WHERE is_active=true'
  )).rows;
  for (const t of all) {
    const a = t.applies_to || {};
    const sourceOk = !a.source || a.source === source;
    const typeOk = !a.doc_type
      || (Array.isArray(a.doc_type) && a.doc_type.includes(doc_type));
    if (sourceOk && typeOk && (a.source || a.doc_type)) return t;
  }
  return all.find((t) => t.template_code === 'standard_review') || all[0];
}

// Instantiate a workflow. Caller must wrap in a transaction.
async function instantiate(client, { versionId, explicit }) {
  // Pull version + document + project context
  const ctx = (await client.query(
    `SELECT dv.id AS version_id, dv.status AS version_status,
            d.id AS document_id, d.project_id, d.discipline, d.doc_type, d.source
     FROM document_versions dv JOIN documents d ON d.id=dv.document_id
     WHERE dv.id=$1`,
    [versionId]
  )).rows[0];
  if (!ctx) throw new Error('Version not found');
  if (ctx.version_status !== 'draft') {
    throw new Error(`Cannot start workflow on status=${ctx.version_status}`);
  }

  const tpl = await pickTemplate(client, {
    source: ctx.source, doc_type: ctx.doc_type, explicit,
  });
  if (!tpl) throw new Error('No applicable workflow template');

  const tplSteps = (await client.query(
    'SELECT * FROM workflow_template_steps WHERE template_code=$1 ORDER BY sequence',
    [tpl.template_code]
  )).rows;
  if (!tplSteps.length) throw new Error('Template has no steps');

  const inst = (await client.query(
    `INSERT INTO workflow_instances
       (document_version_id, template_code, current_step, current_step_sequence, status, started_at)
     VALUES ($1, $2, $3, 1, 'in_progress', now())
     RETURNING *`,
    [versionId, tpl.template_code, tplSteps[0].step_name]
  )).rows[0];

  // Create every step. First one becomes active with a resolved assignee; the rest are pending.
  for (const s of tplSteps) {
    const isFirst = s.sequence === 1;
    const assignee = isFirst
      ? await resolveAssignee(client, {
          projectId: ctx.project_id,
          role: s.assignee_role,
          discipline: ctx.discipline,
        })
      : null;
    const dueAt = isFirst && s.sla_days
      ? new Date(Date.now() + s.sla_days * 86400000)
      : null;
    await client.query(
      `INSERT INTO workflow_steps
        (instance_id, step_name, sequence, assignee_id, assignee_role, due_at, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [inst.id, s.step_name, s.sequence, assignee, s.assignee_role, dueAt,
       isFirst ? 'active' : 'pending']
    );
  }

  await client.query(VERSION_TO_INREVIEW, [versionId]);
  return inst;
}

// Complete one step. Caller must wrap in a transaction.
async function completeStep(client, { stepId, action, comment, userId }) {
  const step = (await client.query(
    `SELECT ws.*, wi.id AS instance_id, wi.template_code,
            wi.current_step_sequence, dv.id AS version_id, dv.document_id,
            d.project_id, d.discipline, d.doc_type
     FROM workflow_steps ws
     JOIN workflow_instances wi ON wi.id=ws.instance_id
     JOIN document_versions dv ON dv.id=wi.document_version_id
     JOIN documents d ON d.id=dv.document_id
     WHERE ws.id=$1`,
    [stepId]
  )).rows[0];
  if (!step) throw new Error('Step not found');
  if (step.status !== 'active') throw new Error(`Step is ${step.status}, not active`);
  if (step.assignee_id !== userId) {
    throw new Error('Only the assignee can complete this step');
  }
  if (!['approved', 'rejected', 'commented'].includes(action)) {
    throw new Error('action must be approved | rejected | commented');
  }

  // 'commented' doesn't advance the step
  if (action === 'commented') {
    await client.query(
      `INSERT INTO audit_logs (user_id, action, entity_type, entity_id, detail)
       VALUES ($1,'workflow.comment','workflow_step',$2,$3)`,
      [userId, stepId, JSON.stringify({ comment })]
    );
    return { advanced: false };
  }

  // Mark the current step done
  await client.query(
    `UPDATE workflow_steps
     SET status='completed', completed_at=now(), action=$1, comment=$2, completed_by=$3
     WHERE id=$4`,
    [action, comment || null, userId, stepId]
  );

  // Rejected — version goes back to draft, instance cancelled
  if (action === 'rejected') {
    await client.query(
      `UPDATE workflow_instances SET status='cancelled', completed_at=now() WHERE id=$1`,
      [step.instance_id]
    );
    await client.query(VERSION_TO_DRAFT, [step.version_id]);
    return { advanced: false, rejected: true };
  }

  // Approved — look for the next step
  const next = (await client.query(
    `SELECT * FROM workflow_steps
     WHERE instance_id=$1 AND sequence>$2
     ORDER BY sequence LIMIT 1`,
    [step.instance_id, step.sequence]
  )).rows[0];

  if (!next) {
    // Last step done — complete the instance and set the version's final status
    const tpl = (await client.query(
      `SELECT final_status_on_complete FROM workflow_templates WHERE template_code=$1`,
      [step.template_code]
    )).rows[0];
    await client.query(
      `UPDATE workflow_instances
       SET status='completed', completed_at=now(), current_step=NULL, current_step_sequence=NULL
       WHERE id=$1`,
      [step.instance_id]
    );
    await client.query(VERSION_TO_FINAL, [step.version_id, tpl.final_status_on_complete]);
    return { advanced: true, completed: true, final_status: tpl.final_status_on_complete };
  }

  // Advance to the next step and resolve its assignee
  const assignee = await resolveAssignee(client, {
    projectId: step.project_id,
    role: next.assignee_role,
    discipline: step.discipline,
  });
  const tplStep = (await client.query(
    `SELECT sla_days FROM workflow_template_steps WHERE template_code=$1 AND sequence=$2`,
    [step.template_code, next.sequence]
  )).rows[0];
  const dueAt = tplStep?.sla_days
    ? new Date(Date.now() + tplStep.sla_days * 86400000)
    : null;

  await client.query(
    `UPDATE workflow_steps
     SET status='active', assignee_id=$1, due_at=$2
     WHERE id=$3`,
    [assignee, dueAt, next.id]
  );
  await client.query(
    `UPDATE workflow_instances SET current_step=$1, current_step_sequence=$2 WHERE id=$3`,
    [next.step_name, next.sequence, step.instance_id]
  );

  return { advanced: true, next_step: next.step_name, next_assignee: assignee };
}

async function getMyPendingSteps(client, userId) {
  return (await client.query(
    `SELECT ws.id AS step_id, ws.step_name, ws.due_at,
            wi.template_code, wi.id AS instance_id,
            dv.id AS version_id, dv.revision,
            d.id AS document_id, d.doc_code, d.title, d.discipline, d.doc_type,
            p.id AS project_id, p.code AS project_code, p.name AS project_name
     FROM workflow_steps ws
     JOIN workflow_instances wi ON wi.id=ws.instance_id
     JOIN document_versions dv ON dv.id=wi.document_version_id
     JOIN documents d ON d.id=dv.document_id
     JOIN projects p ON p.id=d.project_id
     WHERE ws.assignee_id=$1 AND ws.status='active'
     ORDER BY ws.due_at NULLS LAST, ws.due_at ASC`,
    [userId]
  )).rows;
}

async function getInstanceForVersion(client, versionId) {
  const inst = (await client.query(
    `SELECT wi.*, wt.name AS template_name
     FROM workflow_instances wi
     LEFT JOIN workflow_templates wt ON wt.template_code=wi.template_code
     WHERE wi.document_version_id=$1`,
    [versionId]
  )).rows[0];
  if (!inst) return null;
  const steps = (await client.query(
    `SELECT ws.*, u.name AS assignee_name
     FROM workflow_steps ws
     LEFT JOIN users u ON u.id=ws.assignee_id
     WHERE ws.instance_id=$1 ORDER BY ws.sequence`,
    [inst.id]
  )).rows;
  return { ...inst, steps };
}

module.exports = {
  instantiate,
  completeStep,
  getMyPendingSteps,
  getInstanceForVersion,
};
```

## 6. server.js changes

I add the require:

```js
const wf = require('./lib/workflow');
```

**Start a workflow** (this replaces the old in_review transition):

```js
app.post('/api/v1/versions/:vid/start-workflow', auth, r(async (req, res) => {
  const { template_code } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const inst = await wf.instantiate(client, {
      versionId: req.params.vid, explicit: template_code,
    });
    await client.query('COMMIT');
    await audit(req.user.id, 'workflow.start', 'workflow_instance', inst.id,
                { template: inst.template_code });
    ok(res, inst);
  } catch (e) {
    await client.query('ROLLBACK');
    return err(res, 400, 40001, e.message);
  } finally { client.release(); }
}));
```

**Complete a step:**

```js
app.post('/api/v1/workflow-steps/:id/complete', auth, r(async (req, res) => {
  const { action, comment } = req.body || {};
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await wf.completeStep(client, {
      stepId: req.params.id, action, comment, userId: req.user.id,
    });
    await client.query('COMMIT');
    await audit(req.user.id, 'workflow.complete_step', 'workflow_step',
                req.params.id, { action, ...out });
    ok(res, out);
  } catch (e) {
    await client.query('ROLLBACK');
    return err(res, 400, 40001, e.message);
  } finally { client.release(); }
}));
```

**My pending tasks:**

```js
app.get('/api/v1/workflow/my-pending', auth, r(async (req, res) => {
  ok(res, await wf.getMyPendingSteps(pool, req.user.id));
}));
```

**Workflow for a specific version:**

```js
app.get('/api/v1/versions/:vid/workflow', auth, r(async (req, res) => {
  const inst = await wf.getInstanceForVersion(pool, req.params.vid);
  if (!inst) return err(res, 404, 40401, 'No workflow for this version');
  ok(res, inst);
}));
```

**List available templates:**

```js
app.get('/api/v1/workflow-templates', auth, r(async (req, res) => {
  const rows = (await pool.query(
    `SELECT t.*, json_agg(s.* ORDER BY s.sequence) AS steps
     FROM workflow_templates t
     LEFT JOIN workflow_template_steps s ON s.template_code=t.template_code
     WHERE t.is_active=true
     GROUP BY t.template_code
     ORDER BY t.template_code`
  )).rows;
  ok(res, rows);
}));
```

I drop the old `POST /versions/:vid/transition`. If I wanted an escape hatch for controllers I could keep it as an override path, but for now the workflow is the only way to move a version forward.

## 7. Frontend changes — App.jsx

### 7.1 A new Tasks tab

```jsx
<nav className="tabs">
  <button className={tab === 'register' ? 'tab active' : 'tab'}
          onClick={() => setTab('register')}>Register</button>
  <button className={tab === 'tasks' ? 'tab active' : 'tab'}
          onClick={() => setTab('tasks')}>My tasks</button>
  <button className={tab === 'inbox' ? 'tab active' : 'tab'}
          onClick={() => setTab('inbox')}>Inbox</button>
</nav>

{tab === 'tasks' && <TaskInbox onChange={load} />}
```

### 7.2 The TaskInbox component

```jsx
function TaskInbox({ onChange }) {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState('');
  const [actingOn, setActingOn] = useState(null);

  const load = () => api.get('/workflow/my-pending')
    .then(setTasks).catch((e) => setError(e.message));
  useEffect(load, []);

  const act = async (stepId, action) => {
    const comment = action === 'rejected'
      ? prompt('Reason for rejection (optional):')
      : (action === 'commented' ? prompt('Comment:') : null);
    setActingOn(stepId);
    try {
      await api.post(`/workflow-steps/${stepId}/complete`, { action, comment });
      load(); onChange?.();
    } catch (e) { setError(e.message); }
    finally { setActingOn(null); }
  };

  if (!tasks.length) return <div className="card muted">No pending tasks.</div>;

  return (
    <div className="card">
      <h3>My pending tasks</h3>
      <table className="d-table">
        <thead>
          <tr><th>Document</th><th>Step</th><th>Due</th><th></th></tr>
        </thead>
        <tbody>
          {tasks.map((t) => (
            <tr key={t.step_id}>
              <td>
                <div className="mono">{t.doc_code} · Rev {t.revision}</div>
                <div className="muted small">{t.title}</div>
              </td>
              <td>{t.step_name}<div className="muted small">{t.template_code}</div></td>
              <td className="muted small">
                {t.due_at ? new Date(t.due_at).toLocaleDateString() : '—'}
              </td>
              <td style={{ textAlign: 'right' }}>
                <button onClick={() => act(t.step_id, 'commented')}
                        disabled={actingOn === t.step_id}>Comment</button>
                <button onClick={() => act(t.step_id, 'rejected')}
                        disabled={actingOn === t.step_id}>Reject</button>
                <button className="btn-pri" onClick={() => act(t.step_id, 'approved')}
                        disabled={actingOn === t.step_id}>Approve</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {error && <div className="error">{error}</div>}
    </div>
  );
}
```

### 7.3 DocumentDetail changes

The per-version row of transition buttons goes away. Now I show one button on draft versions, and `Send transmittal` once a version reaches `approved` or `issued`:

```jsx
{v.status === 'draft' && (
  <button className="btn-pri" onClick={() => startWorkflow(v.id)}>
    Start workflow
  </button>
)}

{(v.status === 'approved' || v.status === 'issued') && (
  <button className="btn-pri" onClick={() => setSendFor(v.id)}>Send transmittal</button>
)}
```

```jsx
const startWorkflow = async (vid) => {
  try {
    // For simplicity I let the engine pick the template from applies_to.
    // If I wanted a chooser, I'd fetch /workflow-templates first.
    await api.post(`/versions/${vid}/start-workflow`, {});
    load(); onChange?.();
  } catch (e) { setError(e.message); }
};
```

### 7.4 Showing workflow progress

In the version table I add a progress column:

```jsx
const [workflows, setWorkflows] = useState({});
useEffect(() => {
  Promise.all(
    data.versions.map((v) =>
      api.get(`/versions/${v.id}/workflow`).then((wf) => [v.id, wf]).catch(() => [v.id, null])
    )
  ).then((pairs) => setWorkflows(Object.fromEntries(pairs)));
}, [data]);

<td>
  {workflows[v.id]
    ? <WorkflowProgress wf={workflows[v.id]} />
    : <span className="muted small">No workflow</span>}
</td>
```

```jsx
function WorkflowProgress({ wf }) {
  const completed = wf.steps.filter((s) => s.status === 'completed').length;
  const total = wf.steps.length;
  return (
    <div title={wf.steps.map((s) =>
      `${s.sequence}. ${s.step_name} (${s.status}${s.assignee_name ? ' → ' + s.assignee_name : ''})`
    ).join('\n')}>
      <div className="small">{wf.template_name}</div>
      <div className="muted small">{completed} / {total} steps · {wf.status}</div>
    </div>
  );
}
```

## 8. How I test it

1. Sign in as Alice (controller + PM), create a STR/DWG document, upload Rev A.
2. On that version click **Start workflow**. The engine picks `standard_review`; step 1 is IDC, assignee resolves to Bob (STR discipline lead).
3. Sign in as Bob, open the Tasks tab, click **Approve**. The engine advances to step 2 (Internal review), still Bob.
4. Approve again — step 3 (Client review) becomes active with Alice as assignee.
5. Sign back in as Alice, approve step 3, then step 4 (Project approval).
6. The instance completes; the version flips to `approved`.
7. Now I can hit **Send transmittal**.

For the reject path: start a fresh workflow, then **Reject** at step 2. The version drops back to `draft`, the instance becomes `cancelled`, and prior step rows are preserved as history.

For the comment path: hit **Comment** before approving. The step stays active, the comment is in the audit log, and approve/reject still works.

## 9. What I'm leaving for later

- **Multiple assignees with quorum.** Templates get a `quorum` field (`all` / `any`). Right now I assume one assignee per step.
- **Parallel branches.** For things like multi-discipline IDC happening at the same time, template steps need a `parallel_group`.
- **Reassignment.** When someone is out, I add `POST /workflow-steps/:id/reassign`.
- **Delegation.** Same shape as reassignment, but initiated by the assignee themself.
- **SLA reminders and escalation.** A cron job scans `due_at < now() AND status='active'` and emails reminders; after X days the task escalates to a manager.
- **Backfilling.** Versions that went through manual transitions during the MVP — do I retroactively create workflow instances? If audit-log consistency matters, I write a script that reconstructs instances from the existing audit trail.
